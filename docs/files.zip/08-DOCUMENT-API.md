# 08 - Document Storage API Service

**Version**: 2.0  
**Base Path**: `/api/v1/documents`  
**Status**: Text Storage Design  
**Service Type**: Synchronous Storage & Retrieval

## Service Overview

Manages storage and retrieval of generated documents (resumes and cover letters) in text format with future PDF export capability.

## Database Schema

### DocumentModel
```sql
CREATE TABLE documents (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    generation_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    job_id TEXT NOT NULL,
    document_type TEXT NOT NULL,
    title TEXT NOT NULL,
    content_text TEXT NOT NULL,
    content_format TEXT DEFAULT 'plain',
    metadata JSONB NOT NULL,
    file_path TEXT,
    notes TEXT,
    version INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (generation_id) REFERENCES generations(id) ON DELETE CASCADE,
    FOREIGN KEY (profile_id) REFERENCES master_profiles(id) ON DELETE SET NULL,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE SET NULL
);
```

## API Endpoints with Detailed Dataflow

### 1. POST /documents - Create Document from Generation

**Dataflow Implementation:**
```
Step 1: Request Validation
- Extract JWT to get user_id
- Parse generation_id from request
- Parse optional notes

Step 2: Load Generation
SELECT * FROM generations 
WHERE id = ? AND user_id = ?

If not found, return 404

Step 3: Load Related Data
Query job details:
SELECT title, company FROM jobs WHERE id = ?

Query profile:
SELECT personal_info FROM master_profiles WHERE id = ?

Step 4: Generate Title
If not provided:
  If resume: "{job_title} - {company} Resume"
  If cover_letter: "{job_title} - {company} Cover Letter"

Step 5: Create Document Record
INSERT INTO documents (
  id, user_id, generation_id, profile_id, job_id,
  document_type, title, content_text, content_format,
  metadata, notes
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)

Copy metadata from generation:
- ATS score
- Keyword coverage
- Word count
- Component IDs included

Step 6: Generate File Path (Future)
Path: /documents/{user_id}/{document_id}.txt

Step 7: Response
Return 201 Created with document details
```

### 2. GET /documents - List User Documents

**Dataflow Implementation:**
```
Step 1: Authentication
- Extract JWT to get user_id

Step 2: Parse Query Parameters
- document_type (resume, cover_letter)
- job_id (filter by job)
- profile_id (filter by profile)
- created_after (datetime)
- limit (1-100, default 20)
- offset (pagination)

Step 3: Build Query
SELECT d.*, j.title as job_title, j.company
FROM documents d
JOIN jobs j ON d.job_id = j.id
WHERE d.user_id = ?
  AND (document_type = ? OR ? IS NULL)
  AND (job_id = ? OR ? IS NULL)
  AND (created_after > ? OR ? IS NULL)
ORDER BY created_at DESC
LIMIT ? OFFSET ?

Step 4: Calculate Statistics
SELECT 
  COUNT(*) as total_documents,
  COUNT(CASE WHEN document_type = 'resume' THEN 1 END) as resumes,
  COUNT(CASE WHEN document_type = 'cover_letter' THEN 1 END) as cover_letters,
  AVG((metadata->>'ats_score')::float) as avg_ats_score
FROM documents WHERE user_id = ?

Step 5: Response
Return document list with statistics
```

### 3. GET /documents/{id} - Get Document Details

**Dataflow Implementation:**
```
Step 1: Authorization
- Extract JWT to get user_id
- Query document with ownership check

Step 2: Load Full Document
SELECT d.*, 
  j.title as job_title, 
  j.company,
  j.description as job_description,
  p.personal_info
FROM documents d
JOIN jobs j ON d.job_id = j.id
JOIN master_profiles p ON d.profile_id = p.id
WHERE d.id = ? AND d.user_id = ?

Step 3: Parse Content Structure
If resume:
  Split by sections (EXPERIENCE, EDUCATION, etc.)
  Create structured response

If cover_letter:
  Split by paragraphs
  Identify salutation and closing

Step 4: Response
Return complete document with all metadata
```

### 4. PUT /documents/{id} - Update Document

**Dataflow Implementation:**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Validate Updates
Allowed updates:
- title
- notes
- content_text (manual edits)

Step 3: Track Changes
If content_text changed:
  - Calculate diff from original
  - Update version number
  - Store edit metadata

Step 4: Update Record
UPDATE documents SET
  title = COALESCE(?, title),
  notes = COALESCE(?, notes),
  content_text = COALESCE(?, content_text),
  version = version + 1,
  updated_at = NOW()
WHERE id = ? AND user_id = ?

Step 5: Response
Return updated document
```

### 5. DELETE /documents/{id} - Delete Document

**Dataflow Implementation:**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Get File Path (if exists)
SELECT file_path FROM documents WHERE id = ?

Step 3: Delete File (if exists)
Remove file from filesystem

Step 4: Delete Record
DELETE FROM documents WHERE id = ? AND user_id = ?

Step 5: Response
Return 204 No Content
```

### 6. GET /documents/{id}/download.txt - Download as Text

**Dataflow Implementation:**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Get Content
SELECT content_text, title, document_type
FROM documents WHERE id = ? AND user_id = ?

Step 3: Format Filename
Filename: "{name}_{type}_{date}.txt"
Clean special characters from filename

Step 4: Set Response Headers
Content-Type: text/plain; charset=utf-8
Content-Disposition: attachment; filename="{filename}"
Content-Length: {byte_length}

Step 5: Response
Stream text content as file download
```

### 7. GET /documents/{id}/preview - Preview Document

**Dataflow Implementation:**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Get Content
SELECT content_text, document_type FROM documents
WHERE id = ? AND user_id = ?

Step 3: Generate Preview
If text length > 500:
  Take first 500 characters
  Add "... [truncated]"

Step 4: Response
Return preview text
```

### 8. POST /documents/{id}/duplicate - Duplicate Document

**Dataflow Implementation:**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Load Original
SELECT * FROM documents WHERE id = ? AND user_id = ?

Step 3: Create Duplicate
- Generate new ID
- Copy all fields
- Update title: "{original_title} (Copy)"
- Reset version to 1

Step 4: Insert Duplicate
INSERT INTO documents (...) VALUES (...)

Step 5: Response
Return new document details
```

### 9. POST /documents/{id}/export/{format} - Export to Format

**Dataflow Implementation (Future):**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Load Document
SELECT content_text FROM documents WHERE id = ?

Step 3: Convert Based on Format
If format = 'pdf':
  - Apply PDF template
  - Use ReportLab or similar
  - Generate PDF bytes

If format = 'docx':
  - Create Word document
  - Apply styling
  - Generate DOCX bytes

If format = 'latex':
  - Apply LaTeX template
  - Compile to PDF if requested

Step 4: Store Export
- Save file to storage
- Update document with export path

Step 5: Response
Return download URL for exported file
```

## Document Versioning

### Version Tracking
```
When document edited:
1. Compare new content with original
2. If > 10% changed:
   - Increment version
   - Store change summary
3. Keep last 3 versions in history

Version metadata stored:
{
  "version": 2,
  "changes": {
    "lines_added": 5,
    "lines_removed": 3,
    "sections_modified": ["experience", "skills"]
  },
  "edited_at": "2025-11-19T14:00:00Z"
}
```

### Change Detection
```python
def detect_changes(original, edited):
    original_lines = original.split('\n')
    edited_lines = edited.split('\n')
    
    added = len([l for l in edited_lines if l not in original_lines])
    removed = len([l for l in original_lines if l not in edited_lines])
    
    change_percentage = (added + removed) / len(original_lines) * 100
    
    return {
        'lines_added': added,
        'lines_removed': removed,
        'change_percentage': change_percentage
    }
```

## Search and Filtering

### Full-Text Search Implementation
```sql
-- Add full-text search index
CREATE INDEX idx_documents_content_text 
ON documents USING GIN (to_tsvector('english', content_text));

-- Search query
SELECT * FROM documents
WHERE user_id = ?
  AND to_tsvector('english', content_text) @@ plainto_tsquery('english', ?)
ORDER BY ts_rank(to_tsvector('english', content_text), 
                 plainto_tsquery('english', ?)) DESC
```

### Advanced Filtering
```
Supported filters:
- ATS score range: metadata->>'ats_score' BETWEEN ? AND ?
- Keyword coverage: metadata->>'keyword_coverage' > ?
- Date range: created_at BETWEEN ? AND ?
- Has notes: notes IS NOT NULL
- Version: version > 1 (edited documents)
```

## Storage Optimization

### Text Compression
```
For large documents (>10KB):
1. Compress using zlib before storage
2. Store compressed in content_text
3. Set metadata flag: "compressed": true
4. Decompress on retrieval
```

### Archival Strategy
```
Documents older than 90 days:
1. Move to archive table
2. Compress content
3. Remove from main table
4. Keep metadata for quick access
```

## Error Response Standards

| Code | Scenario | Response Body |
|------|----------|---------------|
| 404 | Document not found | `{"error": "Document not found"}` |
| 403 | Not owner | `{"error": "Not authorized to access document"}` |
| 413 | Content too large | `{"error": "Document exceeds size limit"}` |
| 422 | Export failed | `{"error": "Failed to export to format"}` |