# 07 - Generation API Service

**Version**: 2.0  
**Base Path**: `/api/v1/generations`  
**Status**: Text Generation Design  
**Service Type**: Mixed (Fast Logic + AI Generation)

## Service Overview

Generates job-tailored resumes (logic-based compilation) and cover letters (AI generation) in text format.

## Database Schema

### GenerationModel
```sql
CREATE TABLE generations (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    job_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    ranking_id TEXT,
    document_type TEXT NOT NULL,
    content_text TEXT NOT NULL,
    content_format TEXT DEFAULT 'plain',
    metadata JSONB NOT NULL,
    generation_params JSONB,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (profile_id) REFERENCES master_profiles(id) ON DELETE CASCADE,
    FOREIGN KEY (ranking_id) REFERENCES job_content_rankings(id)
);
```

## API Endpoints with Detailed Dataflow

### 1. POST /generations/resume/text - Generate Resume

**Dataflow Implementation:**
```
Step 1: Request Validation
- Extract JWT to get user_id
- Parse job_id from request
- Parse options:
  * use_ranking (boolean, default true)
  * use_enhanced (boolean, default true)
  * include_summary (boolean, default true)
  * max_pages (integer, default 1)
  * custom_prompt (string, optional)

Step 2: Load Required Data
Query 1: Get job details
SELECT title, company FROM jobs 
WHERE id = ? AND user_id = ?

Query 2: Get profile with all components
SELECT * FROM master_profiles WHERE user_id = ?
SELECT * FROM experiences WHERE profile_id = ?
SELECT * FROM projects WHERE profile_id = ?
SELECT * FROM education WHERE profile_id = ?

Query 3: Get or create ranking
If use_ranking = true:
  SELECT ranking_data FROM job_content_rankings 
  WHERE job_id = ? AND user_id = ?
  
  If not exists:
    Call Rankings API to create ranking
    Wait for response

Step 3: Apply Component Selection
Based on ranking_data:
- Filter experiences where include = true
- Filter projects where include = true
- Order skills by relevance

If use_enhanced = true:
  Use enhanced_description fields
Else:
  Use original description fields

Step 4: Compile Resume (Pure Logic)
Build text sections:

Header Section:
{full_name}
{title from most recent experience}
{location} | {email} | {phone}
{linkedin} | {github} | {website}

Summary Section (if include_summary):
PROFESSIONAL SUMMARY
{enhanced_summary or professional_summary}

Experience Section:
EXPERIENCE
For each included experience (ordered by ranking):
  {title}
  {company} | {location} | {date_range}
  {reordered bullet points from description}

Projects Section:
PROJECTS
For each included project (ordered by ranking):
  {name}
  {date_range if exists}
  {reordered description points}

Education Section:
EDUCATION
For each education:
  {degree} in {field}
  {institution} | {location} | {dates}
  GPA: {gpa} (if > 3.5)

Skills Section:
SKILLS
Technical: {ordered technical skills}
Soft: {ordered soft skills}

Step 5: Format Text
- Apply consistent spacing (2 lines between sections)
- Ensure bullet points use "• " prefix
- Format dates as "MMM YYYY"
- Wrap lines at 80 characters

Step 6: Calculate Metadata
- Count words
- Count lines
- Estimate pages (45 lines per page)
- Calculate ATS score (keyword match %)
- List included component IDs

Step 7: Store Generation
INSERT INTO generations (
  id, user_id, job_id, profile_id, ranking_id,
  document_type, content_text, content_format,
  metadata, generation_params
) VALUES (?, ?, ?, ?, ?, 'resume', ?, 'plain', ?, ?)

Step 8: Response
Return generated resume with metadata
```

### 2. POST /generations/cover-letter/text - Generate Cover Letter

**Dataflow Implementation:**
```
Step 1: Request Validation
- Extract JWT to get user_id
- Parse job_id
- Parse options:
  * tone (professional, enthusiastic, formal)
  * length (short, medium, long)
  * include_salary_discussion (boolean)
  * custom_prompt (optional)

Step 2: Load Required Data
Query 1: Get job details
SELECT * FROM jobs WHERE id = ? AND user_id = ?

Query 2: Get enhanced profile
SELECT enhanced_summary, skills FROM master_profiles
SELECT enhanced_description FROM experiences
SELECT enhanced_description FROM projects

Query 3: Get cover letter sample
SELECT full_text, extracted_style FROM sample_documents
WHERE user_id = ? AND document_type = 'cover_letter_sample'

Step 3: Prepare LLM Prompt
Construct prompt with:
- Sample cover letter for style
- Job description and requirements
- Enhanced profile content
- Specific instructions for tone/length
- Custom prompt if provided

Step 4: Call LLM for Generation
Send to LLM API:
{
  "sample_cover_letter": {sample_text},
  "writing_style": {extracted_style},
  "job": {job_details},
  "profile": {enhanced_profile},
  "instructions": {
    "tone": tone,
    "length": length,
    "include_salary": include_salary_discussion
  }
}

Step 5: Process LLM Response
- Extract generated text
- Validate length (150-500 words)
- Check for placeholder text
- Ensure proper letter format

Step 6: Format Cover Letter
Structure as:
- Salutation
- Opening paragraph
- 2-3 body paragraphs
- Closing paragraph
- Sign-off

Step 7: Calculate Metadata
- Word count
- Paragraph count
- Style match score
- Job alignment score
- AI model used
- Generation time

Step 8: Store Generation
INSERT INTO generations (
  id, user_id, job_id, profile_id,
  document_type, content_text, content_format,
  metadata, generation_params
) VALUES (?, ?, ?, ?, 'cover_letter', ?, 'plain', ?, ?)

Step 9: Response
Return generated cover letter
```

### 3. GET /generations - List Generations

**Dataflow Implementation:**
```
Step 1: Authentication
- Extract JWT to get user_id

Step 2: Parse Filters
- document_type (resume, cover_letter)
- job_id
- created_after (datetime)
- limit (1-100, default 20)
- offset

Step 3: Query Generations
SELECT g.*, j.title, j.company 
FROM generations g
JOIN jobs j ON g.job_id = j.id
WHERE g.user_id = ?
  AND (document_type = ? OR ? IS NULL)
  AND (job_id = ? OR ? IS NULL)
  AND (created_at > ? OR ? IS NULL)
ORDER BY created_at DESC
LIMIT ? OFFSET ?

Step 4: Response
Return list with pagination
```

### 4. GET /generations/{id} - Get Generation Details

**Dataflow Implementation:**
```
Step 1: Authorization
- Extract JWT and verify ownership

Step 2: Query Generation
SELECT * FROM generations WHERE id = ? AND user_id = ?

Step 3: Parse Content
- Split into sections if resume
- Split into paragraphs if cover letter

Step 4: Response
Return full generation details
```

### 5. GET /generations/{id}/download.txt - Download as Text

**Dataflow Implementation:**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Get Content
SELECT content_text, document_type FROM generations
WHERE id = ? AND user_id = ?

Step 3: Set Headers
- Content-Type: text/plain
- Content-Disposition: attachment; filename="{type}_{timestamp}.txt"

Step 4: Response
Return raw text content for download
```

### 6. DELETE /generations/{id} - Delete Generation

**Dataflow Implementation:**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Delete
DELETE FROM generations WHERE id = ? AND user_id = ?

Step 3: Response
Return 204 No Content
```

### 7. POST /generations/{id}/convert/{format} - Format Conversion

**Dataflow Implementation:**
```
Step 1: Load Original
SELECT content_text FROM generations WHERE id = ?

Step 2: Convert Format
If format = 'latex':
  Apply LaTeX template
  \documentclass{article}
  \begin{document}
  {converted_content}
  \end{document}

If format = 'markdown':
  # {Name}
  ## {Title}
  {converted_content}

If format = 'html':
  <html><body>
  {converted_content}
  </body></html>

Step 3: Store Converted
Create new generation record with format

Step 4: Response
Return converted content
```

## Resume Compilation Templates

### Text Section Templates
```
HEADER_TEMPLATE:
{full_name}
{title}
{location} | {email} | {phone}
{linkedin} | {github}

EXPERIENCE_TEMPLATE:
{title}
{company} | {location} | {start_date} - {end_date|"Present"}
{bullet_points}

PROJECT_TEMPLATE:
{name} | {technologies}
{dates if exists}
{description_points}

EDUCATION_TEMPLATE:
{degree} in {field}
{institution} | {location} | {graduation_date}
GPA: {gpa}/4.0 {honors}
```

### Bullet Point Formatting
```
For each bullet:
- Ensure starts with "• "
- Capitalize first letter
- No period at end unless multiple sentences
- Max 2 lines (160 characters)
```

## Cover Letter Generation Prompts

### Main Generation Prompt
```
Using this writing style from sample:
{sample_cover_letter}

Style analysis:
{extracted_style}

Write a cover letter for:
Position: {job_title} at {company}
Description: {job_description}
Requirements: {requirements}

Using candidate profile:
{enhanced_profile_content}

Requirements:
1. Match the tone and vocabulary of the sample
2. Address specific job requirements
3. Length: {length} (300-400 words for medium)
4. Include specific achievements with metrics
5. Show knowledge of company
6. End with call to action

{custom_prompt}

Generate the cover letter:
```

### Style Matching Validation
```
After generation, check:
1. Vocabulary similarity score > 70%
2. Sentence structure similarity > 60%
3. Tone consistency check
4. No placeholder text like [Company] or [Position]
```

## ATS Score Calculation

### Keyword Coverage Algorithm
```
Step 1: Extract job keywords
- From parsed_keywords field
- From requirements text

Step 2: Count matches in resume
- Exact matches: 1.0 point
- Stem matches: 0.7 points
- Synonym matches: 0.5 points

Step 3: Calculate score
score = matched_keywords / total_keywords * 100
```

## Error Response Standards

| Code | Scenario | Response Body |
|------|----------|---------------|
| 400 | Missing job/profile | `{"error": "Job or profile not found"}` |
| 422 | Generation failed | `{"error": "Failed to generate document"}` |
| 503 | LLM unavailable | `{"error": "Generation service unavailable"}` |
| 413 | Content too long | `{"error": "Generated content exceeds limits"}` |