# JobWise AI Generation System - Complete API Documentation

**Version**: 3.0
**Last Updated**: November 2025
**Status**: Complete Design Documentation

## System Overview

The JobWise AI Generation System consists of 9 interconnected API services working together to provide AI-enhanced resume and cover letter generation.

## API Services Architecture

### Core Services (Existing)
1. **Authentication API** (`/api/v1/auth`) - User authentication and JWT management
2. **Profile API v3.0** (`/api/v1/profiles`) - Master profile with enhanced descriptions
3. **Job API** (`/api/v1/jobs`) - Job description management

### New AI Pipeline Services
4. **Sample Documents API** (`/api/v1/samples`) - Resume/cover letter sample uploads
5. **Enhancement API** (`/api/v1/enhancement`) - AI-powered profile enhancement
6. **Rankings API** (`/api/v1/rankings`) - Job-specific content ranking
7. **Generation API v2.0** (`/api/v1/generations`) - Text document generation

## Complete User Journey

### Phase 1: Initial Setup
```
1. User Registration
   POST /api/v1/auth/register
   → Creates user account
   → Returns JWT tokens

2. Profile Creation
   POST /api/v1/profiles
   → Creates master profile
   → Stores experiences, projects, skills

3. Sample Upload
   POST /api/v1/samples/upload-resume
   POST /api/v1/samples/upload-cover-letter
   → Stores sample documents
   → Extracts text for analysis
```

### Phase 2: AI Enhancement
```
4. Style Extraction (Automatic)
   → Analyzes resume structure patterns
   → Extracts cover letter writing style
   → Stores in extracted_style JSON

5. Profile Enhancement
   POST /api/v1/enhancement/trigger
   → Enhances all descriptions using AI
   → Applies extracted writing style
   → Maintains current + previous versions

6. Enhancement Review
   GET /api/v1/enhancement/comparison
   → Compare original vs enhanced
   → Select preferred versions
```

### Phase 3: Job Application
```
7. Job Management
   POST /api/v1/jobs (create or import job)
   → Stores job description
   → Extracts keywords

8. Content Ranking
   POST /api/v1/rankings/create
   → AI ranks experiences/projects
   → Reorders bullet points
   → Optimizes for job match

9. Resume Generation
   POST /api/v1/generations/resume/text
   → Compiles resume using ranking
   → No AI needed (pure logic)
   → Returns formatted text

10. Cover Letter Generation
    POST /api/v1/generations/cover-letter/text
    → AI generates tailored letter
    → Uses sample style
    → Returns formatted text
```

## Database Schema Summary

### Core Tables (Existing)
- `users` - User accounts
- `master_profiles` - User profiles with enhancement fields
- `experiences` - Work history with enhanced descriptions
- `projects` - Projects with enhanced descriptions
- `jobs` - Job descriptions

### New Tables
- `sample_documents` - Uploaded resume/cover letter samples
- `job_content_rankings` - Job-specific content rankings
- `generations` - Generated documents (text storage)

### Enhancement Fields Added
```sql
-- Added to master_profiles
enhanced_summary TEXT
previous_enhanced_summary TEXT
enhancement_version INTEGER
last_enhanced_at DATETIME
enhancement_status TEXT

-- Added to experiences
enhanced_description TEXT
previous_enhanced_description TEXT
use_enhanced BOOLEAN

-- Added to projects
enhanced_description TEXT
previous_enhanced_description TEXT
use_enhanced BOOLEAN
```

## API Endpoints Summary

### Authentication (`/api/v1/auth`)
- POST `/register` - Create account
- POST `/login` - Authenticate
- GET `/me` - Get current user
- POST `/refresh` - Refresh token

### Profile (`/api/v1/profiles`)
- POST `/` - Create profile
- GET `/me` - Get user profile with enhanced fields
- PUT `/{id}` - Update profile
- PUT `/{id}/preferences` - Set enhanced vs original

### Jobs (`/api/v1/jobs`)
- POST `/` - Create job
- GET `/` - List user jobs
- GET `/{id}` - Get job details
- PUT `/{id}` - Update job
- DELETE `/{id}` - Delete job

### Sample Documents (`/api/v1/samples`)
- POST `/upload-resume` - Upload resume sample
- POST `/upload-cover-letter` - Upload cover letter sample
- GET `/` - Get user samples
- GET `/{id}` - Get specific sample
- DELETE `/{id}` - Delete sample

### Enhancement (`/api/v1/enhancement`)
- POST `/trigger` - Start enhancement
- GET `/status` - Check progress
- GET `/history` - Enhancement history
- GET `/comparison` - Compare versions
- POST `/retry` - Retry failed enhancement

### Rankings (`/api/v1/rankings`)
- POST `/create` - Create ranking for job
- GET `/{job_id}` - Get existing ranking
- GET `/` - List all rankings
- DELETE `/{job_id}` - Delete ranking
- POST `/{job_id}/refresh` - Force refresh

### Generation (`/api/v1/generations`)
- POST `/resume/text` - Generate resume
- POST `/cover-letter/text` - Generate cover letter
- GET `/` - List generations
- GET `/{id}` - Get generation details
- GET `/{id}/download.txt` - Download as text
- DELETE `/{id}` - Delete generation

## Key Design Decisions

### 1. Text Storage in Database
- All generated content stored as TEXT in database
- Enables easy querying and display
- Future support for LaTeX/Markdown formatting

### 2. Enhancement Versioning
- Tracks sample document version used
- Maintains current + previous enhanced versions
- Third enhancement rotates (previous = current, current = new)

### 3. Job-Specific Everything
- Rankings tied to specific job_id
- Resume generation requires job context
- Cover letters tailored per job

### 4. Separation of Concerns
- LLM for enhancement and ranking
- Pure logic for resume compilation
- Fast generation after initial ranking

## Data Flow Patterns

### Enhancement Flow
```
Samples → Style Extraction → Profile Enhancement → Store Enhanced
```

### Generation Flow
```
Job + Profile → Ranking → Resume Compilation → Text Output
Job + Profile + Sample → AI Generation → Cover Letter Output
```

### Version Management
```
First Enhancement: enhanced = new, previous = null
Second Enhancement: previous = first, enhanced = new
Third+ Enhancement: previous = current, enhanced = new
```

## Response Time Expectations

- Profile CRUD: <200ms
- Sample Upload: <2s (includes text extraction)
- Style Extraction: 10-15s (async)
- Profile Enhancement: 30-90s (all components)
- Content Ranking: 3-5s
- Resume Compilation: <2s
- Cover Letter Generation: 5-8s

## Error Handling Strategy

### Prerequisites Validation
- Check profile exists before enhancement
- Check samples uploaded before enhancement
- Check ranking exists before resume generation

### Failure Recovery
- Automatic retry for transient failures
- Manual retry for permanent failures
- Previous versions preserved during failures

### User Feedback
- Clear error messages
- Progress tracking for long operations
- Success confirmations with next steps

## Mobile Integration Guidelines

### State Management
- Cache enhanced descriptions locally
- Store rankings for offline access
- Queue generations when offline

### UI Considerations
- Show enhancement eligibility
- Display progress indicators
- Provide comparison views
- Allow manual overrides

### Performance
- Lazy load enhanced content
- Paginate large lists
- Use background refresh
- Implement pull-to-refresh

## Implementation Priority

### Phase 1: Foundation (Week 1)
1. Database migrations for enhanced fields
2. Sample Documents API
3. Basic upload and storage

### Phase 2: Enhancement (Week 2)
1. Enhancement API implementation
2. Style extraction logic
3. Profile enhancement workflow

### Phase 3: Generation (Week 3)
1. Rankings API
2. Resume compilation logic
3. Cover letter generation

### Phase 4: Polish (Week 4)
1. Error handling improvements
2. Performance optimization
3. Testing and documentation

## Success Metrics

- Enhancement quality: >90% user satisfaction
- Generation speed: <10s total workflow
- ATS scores: >85% average
- Keyword coverage: >80% match
- Zero fabrication: 100% factual accuracy

## Next Steps

1. Review and approve all API specifications
2. Implement database migrations
3. Begin Phase 1 development
4. Set up testing framework
5. Plan mobile app integration

---

**All API documents are ready for implementation. The system design is complete and addresses all requirements for AI-enhanced resume and cover letter generation.**