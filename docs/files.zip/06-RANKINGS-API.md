# 06 - Rankings API Service

**Version**: 1.0  
**Base Path**: `/api/v1/rankings`  
**Status**: New Design  
**Service Type**: Synchronous AI Processing

## Service Overview

Manages job-specific content rankings for resume generation. AI analyzes job descriptions and ranks profile components based on relevance.

## Database Schema

### JobContentRankingModel
```sql
CREATE TABLE job_content_rankings (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    job_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    ranking_data JSONB NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, job_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (profile_id) REFERENCES master_profiles(id) ON DELETE CASCADE
);
```

## API Endpoints with Detailed Dataflow

### 1. POST /rankings/create - Create Job Ranking

**Dataflow Implementation:**
```
Step 1: Request Validation
- Extract JWT to get user_id
- Parse job_id from request
- Parse optional constraints:
  * max_experiences (default: all)
  * max_projects (default: all)
  * target_length (one_page, two_page)
  * enforce_limits (boolean)

Step 2: Load Required Data
Query 1: Get job details
SELECT title, company, description, parsed_keywords, requirements
FROM jobs WHERE id = ? AND user_id = ?

Query 2: Get profile with components
SELECT p.*, 
  (SELECT json_agg(e.*) FROM experiences e WHERE profile_id = p.id) as experiences,
  (SELECT json_agg(pr.*) FROM projects pr WHERE profile_id = p.id) as projects,
  p.skills
FROM master_profiles p WHERE user_id = ?

Step 3: Check Existing Ranking
SELECT id, created_at FROM job_content_rankings
WHERE user_id = ? AND job_id = ?

If exists and created_at > 24 hours ago and not force_refresh:
  Return existing ranking

Step 4: Prepare LLM Request
Construct prompt with:
- Job description and requirements
- List of experiences with enhanced descriptions
- List of projects with enhanced descriptions
- Skills list
- Constraints if provided

Step 5: Call LLM for Ranking
Send to LLM API:
{
  "job": {job_details},
  "experiences": [experience_list],
  "projects": [project_list],
  "skills": skill_list,
  "task": "Rank and reorder components for job relevance"
}

Step 6: Process LLM Response
Parse response to extract:
- Experience rankings with scores
- Project rankings with scores
- Bullet point reordering
- Skills prioritization
- Inclusion recommendations

Step 7: Apply Business Logic
For each component:
- If score >= 70: include = true
- If score < 70 and space available: include = true
- Otherwise: include = false

Apply constraints if enforce_limits = true

Step 8: Store Ranking
INSERT INTO job_content_rankings (
  id, user_id, job_id, profile_id, ranking_data
) VALUES (?, ?, ?, ?, ?)
ON CONFLICT (user_id, job_id) 
DO UPDATE SET 
  ranking_data = EXCLUDED.ranking_data,
  updated_at = NOW()

Step 9: Response
Return ranking with all details
```

### 2. GET /rankings/{job_id} - Get Existing Ranking

**Dataflow Implementation:**
```
Step 1: Authentication
- Extract JWT to get user_id

Step 2: Query Ranking
SELECT r.*, j.title, j.company 
FROM job_content_rankings r
JOIN jobs j ON r.job_id = j.id
WHERE r.job_id = ? AND r.user_id = ?

Step 3: Check Staleness
Ranking is stale if:
- Created > 30 days ago
- Profile updated after ranking created
- Job updated after ranking created

Query staleness:
SELECT 
  (p.updated_at > r.created_at) as profile_updated,
  (j.updated_at > r.created_at) as job_updated
FROM job_content_rankings r
JOIN master_profiles p ON r.profile_id = p.id
JOIN jobs j ON r.job_id = j.id
WHERE r.id = ?

Step 4: Response
Return ranking with staleness metadata
```

### 3. GET /rankings - List All Rankings

**Dataflow Implementation:**
```
Step 1: Authentication
- Extract JWT to get user_id

Step 2: Parse Query Parameters
- limit (1-100, default 20)
- offset (pagination)
- include_stale (boolean, default true)

Step 3: Query Rankings
SELECT r.*, j.title, j.company,
  (p.updated_at > r.created_at) as is_stale
FROM job_content_rankings r
JOIN jobs j ON r.job_id = j.id
JOIN master_profiles p ON r.profile_id = p.id
WHERE r.user_id = ?
ORDER BY r.created_at DESC
LIMIT ? OFFSET ?

Step 4: Filter if include_stale = false
Remove stale rankings from results

Step 5: Response
Return rankings list with pagination
```

### 4. DELETE /rankings/{job_id} - Delete Ranking

**Dataflow Implementation:**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Delete
DELETE FROM job_content_rankings 
WHERE job_id = ? AND user_id = ?

Step 3: Response
Return 204 No Content
```

### 5. POST /rankings/{job_id}/refresh - Force Refresh

**Dataflow Implementation:**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Delete Old Ranking
DELETE FROM job_content_rankings 
WHERE job_id = ? AND user_id = ?

Step 3: Create New Ranking
- Follow same flow as POST /create
- Include custom_prompt from request

Step 4: Response
Return new ranking
```

## LLM Ranking Algorithm

### Ranking Prompt Template
```
Job Details:
Title: {job_title}
Company: {company}
Description: {job_description}
Requirements: {requirements}
Keywords: {keywords}

Candidate Profile:
Experiences:
{for each experience}
- Title: {title}
- Company: {company}
- Description: {enhanced_description}
{end for}

Projects:
{for each project}
- Name: {name}
- Description: {enhanced_description}
{end for}

Skills: {skills_list}

Task: Analyze job-candidate fit and rank components.

For each experience:
1. Calculate relevance score (0-100)
2. Identify which bullet points best match job requirements
3. Reorder bullets by relevance (most relevant first)
4. Provide rationale

For each project:
1. Calculate relevance score (0-100)
2. Reorder description points by relevance
3. Provide rationale

For skills:
1. Order by relevance to job
2. Identify critical vs nice-to-have

Output format:
{
  "experiences": [...],
  "projects": [...],
  "skills": {...}
}
```

### Bullet Point Reordering Logic

**Dataflow:**
```
Step 1: Parse Original Bullets
- Split description by '\n'
- Store original indices

Step 2: Score Each Bullet
For each bullet:
- Match against job keywords
- Match against requirements
- Score 0-100

Step 3: Generate New Order
- Sort by score descending
- Return array of original indices

Example:
Original: [0, 1, 2, 3]
Scores: [60, 90, 75, 40]
New Order: [1, 2, 0, 3]
```

### Inclusion Decision Logic

**Dataflow:**
```
Step 1: Apply Score Threshold
if relevance_score >= 70:
    include = true
    
Step 2: Check Space Constraints
if enforce_limits:
    included_count = 0
    for item in sorted_by_score:
        if included_count < max_allowed:
            item.include = true
            included_count++
        else:
            item.include = false
            
Step 3: Minimum Requirements
Ensure at least 1 experience included
Ensure core skills included
```

## Ranking Data Structure

### Stored JSON Format
```json
{
  "experiences": [
    {
      "id": "exp_123",
      "relevance_score": 95,
      "include": true,
      "bullet_points_order": [2, 0, 1],
      "original_bullets": ["bullet1", "bullet2", "bullet3"],
      "reordered_bullets": ["bullet3", "bullet1", "bullet2"],
      "rationale": "Strong match with cloud architecture requirements"
    }
  ],
  "projects": [
    {
      "id": "proj_456",
      "relevance_score": 88,
      "include": true,
      "bullet_points_order": [1, 0, 2],
      "rationale": "Demonstrates required technical skills"
    }
  ],
  "skills": {
    "ordered_list": ["Python", "AWS", "Docker", "React"],
    "excluded_for_space": ["MIPS", "Assembly"],
    "relevance_map": {
      "Python": 100,
      "AWS": 95,
      "Docker": 85,
      "React": 70
    }
  },
  "recommended_length": {
    "experiences_count": 3,
    "projects_count": 2,
    "constraint_applied": false,
    "estimated_lines": 45,
    "rationale": "Optimal for single-page format"
  },
  "metadata": {
    "job_match_score": 0.87,
    "keyword_coverage": 0.92,
    "ranking_version": 1,
    "created_at": "2025-11-19T11:00:00Z"
  }
}
```

## Staleness Detection

### Check Staleness Logic
```
Ranking becomes stale when:
1. Profile updated after ranking:
   SELECT updated_at FROM master_profiles WHERE id = ?
   Compare with ranking.created_at
   
2. Job updated after ranking:
   SELECT updated_at FROM jobs WHERE id = ?
   Compare with ranking.created_at
   
3. Time-based staleness:
   If ranking.created_at < NOW() - INTERVAL '30 days'
   
4. Sample documents updated:
   SELECT MAX(updated_at) FROM sample_documents WHERE user_id = ?
   Compare with ranking.created_at
```

## Error Response Standards

| Code | Scenario | Response Body |
|------|----------|---------------|
| 400 | Invalid constraints | `{"error": "Invalid constraint values"}` |
| 404 | Job/Profile not found | `{"error": "Job or profile not found"}` |
| 422 | LLM processing failed | `{"error": "Failed to generate ranking"}` |
| 503 | LLM service unavailable | `{"error": "Ranking service temporarily unavailable"}` |