# 09 - Complete System Overview

**Version**: 3.0  
**Last Updated**: November 2025  
**System Name**: JobWise AI Generation System  
**Architecture**: Microservices with Shared Database

## System Architecture Overview

### Service Hierarchy
```
Level 1 - Foundation:
├── 01-Authentication-API (existing)
└── Database Layer (SQLite/PostgreSQL)

Level 2 - Core Data:
├── 02-Profile-API (enhanced v3)
├── 03-Job-API (existing)
└── 04-Sample-Documents-API (new)

Level 3 - AI Processing:
├── 05-Enhancement-API (new)
└── 06-Rankings-API (new)

Level 4 - Generation:
├── 07-Generation-API (redesigned v2)
└── 08-Document-API (text storage)
```

## Complete User Journey with Dataflow

### Phase 1: User Setup
```
1. User Registration
   → POST /auth/register
   → Creates user record
   → Returns JWT tokens
   
2. Profile Creation
   → POST /profiles
   → Creates master profile
   → Stores experiences, projects, education
   → All enhanced fields NULL initially
   
3. Sample Upload
   → POST /samples/upload-resume
   → POST /samples/upload-cover-letter
   → Extracts and stores text
   → Triggers async style extraction
```

### Phase 2: AI Enhancement
```
4. Style Extraction (Async)
   → Worker processes samples
   → Extracts resume structure patterns
   → Extracts cover letter vocabulary/tone
   → Stores in extracted_style JSON
   
5. Profile Enhancement
   → POST /enhancement/trigger
   → Checks prerequisites
   → Queues enhancement jobs
   → Processes all components
   → Applies rotation logic
   → Updates enhanced fields
   
6. Review & Select
   → GET /enhancement/comparison
   → PUT /profiles/{id}/preferences
   → User selects which versions to use
```

### Phase 3: Job Application
```
7. Job Creation
   → POST /jobs (with raw text or structured)
   → Parses job description
   → Extracts keywords
   → Stores in database
   
8. Content Ranking
   → POST /rankings/create
   → AI analyzes job-profile fit
   → Ranks experiences/projects
   → Reorders bullet points
   → Stores ranking data
   
9. Resume Generation
   → POST /generations/resume/text
   → Loads profile, job, ranking
   → Compiles using pure logic
   → No AI needed
   → Returns text document
   
10. Cover Letter Generation
    → POST /generations/cover-letter/text
    → Uses sample style
    → AI generates content
    → Returns text document
    
11. Document Storage
    → POST /documents (from generation)
    → Stores for later access
    → Enables download/export
```

## Database Migration Plan

### Step 1: Add Enhanced Fields
```sql
-- Profile enhancements
ALTER TABLE master_profiles ADD COLUMN enhanced_summary TEXT;
ALTER TABLE master_profiles ADD COLUMN previous_enhanced_summary TEXT;
ALTER TABLE master_profiles ADD COLUMN enhancement_version INTEGER DEFAULT 0;
ALTER TABLE master_profiles ADD COLUMN last_enhanced_at DATETIME;
ALTER TABLE master_profiles ADD COLUMN enhancement_status TEXT DEFAULT 'pending';

-- Experience enhancements
ALTER TABLE experiences ADD COLUMN enhanced_description TEXT;
ALTER TABLE experiences ADD COLUMN previous_enhanced_description TEXT;
ALTER TABLE experiences ADD COLUMN use_enhanced BOOLEAN DEFAULT FALSE;

-- Project enhancements
ALTER TABLE projects ADD COLUMN enhanced_description TEXT;
ALTER TABLE projects ADD COLUMN previous_enhanced_description TEXT;
ALTER TABLE projects ADD COLUMN use_enhanced BOOLEAN DEFAULT FALSE;
```

### Step 2: Create New Tables
```sql
-- Sample documents
CREATE TABLE sample_documents (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    document_type TEXT NOT NULL,
    file_name TEXT NOT NULL,
    file_path TEXT,
    full_text TEXT NOT NULL,
    extracted_style JSONB,
    version INTEGER DEFAULT 1,
    file_size_bytes INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, document_type),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Job content rankings
CREATE TABLE job_content_rankings (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    job_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    ranking_data JSONB NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, job_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (profile_id) REFERENCES master_profiles(id) ON DELETE CASCADE
);

-- Enhancement jobs
CREATE TABLE enhancement_jobs (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    profile_id TEXT NOT NULL,
    status TEXT NOT NULL,
    progress INTEGER DEFAULT 0,
    current_step TEXT,
    sample_version_used INTEGER,
    error_message TEXT,
    started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (profile_id) REFERENCES master_profiles(id) ON DELETE CASCADE
);

-- Generations
CREATE TABLE generations (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    job_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    ranking_id TEXT,
    document_type TEXT NOT NULL,
    content_text TEXT NOT NULL,
    content_format TEXT DEFAULT 'plain',
    metadata JSONB NOT NULL,
    generation_params JSONB,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (profile_id) REFERENCES master_profiles(id) ON DELETE CASCADE,
    FOREIGN KEY (ranking_id) REFERENCES job_content_rankings(id)
);

-- Documents
CREATE TABLE documents (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    generation_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    job_id TEXT NOT NULL,
    document_type TEXT NOT NULL,
    title TEXT NOT NULL,
    content_text TEXT NOT NULL,
    content_format TEXT DEFAULT 'plain',
    metadata JSONB NOT NULL,
    file_path TEXT,
    notes TEXT,
    version INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (generation_id) REFERENCES generations(id) ON DELETE CASCADE,
    FOREIGN KEY (profile_id) REFERENCES master_profiles(id) ON DELETE SET NULL,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE SET NULL
);
```

### Step 3: Create Indexes
```sql
-- Performance indexes
CREATE INDEX idx_sample_docs_user_type ON sample_documents(user_id, document_type);
CREATE INDEX idx_rankings_user_job ON job_content_rankings(user_id, job_id);
CREATE INDEX idx_enhancement_jobs_user ON enhancement_jobs(user_id);
CREATE INDEX idx_generations_user_type ON generations(user_id, document_type);
CREATE INDEX idx_documents_user_type ON documents(user_id, document_type);
```

## API Implementation Order

### Sprint 1: Foundation (Week 1)
```
Day 1-2: Database Migrations
- Run all ALTER TABLE statements
- Create new tables
- Add indexes
- Test migrations on dev

Day 3-4: Sample Documents API
- Implement upload endpoints
- Add text extraction logic
- File storage setup
- Basic style extraction

Day 5: Profile API Updates
- Add enhanced fields to responses
- Implement preferences endpoint
- Update validation logic
```

### Sprint 2: AI Enhancement (Week 2)
```
Day 1-2: Enhancement API
- Enhancement trigger endpoint
- Status tracking
- Async job queue setup

Day 3-4: Enhancement Worker
- Style extraction from samples
- LLM integration for enhancement
- Rotation logic implementation

Day 5: Testing & Refinement
- End-to-end enhancement test
- Error handling
- Performance optimization
```

### Sprint 3: Generation (Week 3)
```
Day 1-2: Rankings API
- Ranking creation logic
- LLM integration for scoring
- Bullet reordering algorithm

Day 3-4: Generation API
- Resume compilation (logic-based)
- Cover letter generation (AI)
- Text formatting

Day 5: Document Storage
- Storage endpoints
- Download functionality
- Version tracking
```

### Sprint 4: Polish (Week 4)
```
Day 1-2: Error Handling
- Comprehensive error responses
- Retry logic for failures
- Validation improvements

Day 3-4: Performance
- Query optimization
- Caching strategy
- Async processing tuning

Day 5: Documentation
- API documentation
- Integration guide
- Deployment instructions
```

## Service Dependencies

### Internal Dependencies
```
Authentication → All Services (JWT validation)
Profile → Enhancement, Rankings, Generation
Jobs → Rankings, Generation
Sample Documents → Enhancement
Enhancement → Profile (updates enhanced fields)
Rankings → Generation (for resume compilation)
Generation → Documents (for storage)
```

### External Dependencies
```
LLM Service (Groq/OpenAI):
- Enhancement API (style application)
- Rankings API (relevance scoring)
- Generation API (cover letter only)

File Storage:
- Sample Documents (original files)
- Documents (future PDF storage)

Text Extraction:
- PyPDF2 (PDF parsing)
- python-docx (DOCX parsing)
```

## Configuration Requirements

### Environment Variables
```env
# Database
DATABASE_URL=postgresql://user:pass@localhost/jobwise
DATABASE_POOL_SIZE=20

# JWT
JWT_SECRET_KEY=your-secret-key
JWT_ALGORITHM=HS256
JWT_EXPIRY_HOURS=1

# LLM Service
LLM_PROVIDER=groq
LLM_API_KEY=your-api-key
LLM_MODEL_ENHANCEMENT=llama-3.3-70b
LLM_MODEL_RANKING=llama-3.1-8b
LLM_MODEL_GENERATION=llama-3.3-70b

# File Storage
UPLOAD_PATH=/app/uploads
MAX_FILE_SIZE_MB=5
ALLOWED_EXTENSIONS=txt,pdf,docx

# Async Processing
REDIS_URL=redis://localhost:6379
WORKER_CONCURRENCY=4
JOB_TIMEOUT_SECONDS=300

# Rate Limiting
RATE_LIMIT_PER_MINUTE=100
LLM_RATE_LIMIT_PER_MINUTE=10
```

### Service Ports
```yaml
services:
  auth_api: 8001
  profile_api: 8002
  job_api: 8003
  sample_api: 8004
  enhancement_api: 8005
  ranking_api: 8006
  generation_api: 8007
  document_api: 8008
  worker: (background)
```

## Monitoring & Metrics

### Key Metrics to Track
```
API Metrics:
- Request count by endpoint
- Response time percentiles (p50, p95, p99)
- Error rate by status code
- Active users per hour

AI Metrics:
- Enhancement completion rate
- Average enhancement time
- Ranking generation time
- LLM API success rate
- Token usage per operation

Business Metrics:
- Documents generated per day
- Average ATS score
- User retention rate
- Feature adoption rate
```

### Health Checks
```
Each service exposes:
GET /health - Basic liveness
GET /ready - Readiness with dependencies

Health check includes:
- Database connectivity
- LLM service availability
- File storage access
- Memory/CPU usage
```

## Security Considerations

### Authentication & Authorization
- JWT required for all endpoints
- User can only access own data
- Profile ownership validation
- Rate limiting per user

### Data Protection
- Sensitive fields encrypted at rest
- No password/token logging
- PII redaction in logs
- Secure file upload validation

### Input Validation
- Pydantic schemas for all inputs
- File type/size validation
- SQL injection prevention
- XSS protection for text content

## Testing Strategy

### Unit Tests
- Service layer logic
- Data validation
- Utility functions
- Error handling

### Integration Tests
- API endpoints
- Database operations
- LLM integration
- File operations

### End-to-End Tests
- Complete user journey
- Enhancement workflow
- Generation pipeline
- Error scenarios

### Performance Tests
- Load testing (100 concurrent users)
- Stress testing (find breaking point)
- Endurance testing (24-hour run)
- Spike testing (sudden load increase)

## Deployment Architecture

### Development
```
Single server:
- All services on one machine
- SQLite database
- Local file storage
- Mock LLM for testing
```

### Production
```
Microservices deployment:
- Each API as separate container
- PostgreSQL cluster
- Redis for queues
- S3 for file storage
- Load balancer
- Auto-scaling groups
```

## Success Criteria

### Technical Success
- All APIs < 200ms response time
- 99.9% uptime
- Zero data loss
- < 1% error rate

### Business Success
- 90% enhancement satisfaction
- 85% average ATS score
- 80% keyword coverage
- 100% factual accuracy

### User Experience
- 3-click resume generation
- < 30s total generation time
- Mobile-responsive
- Offline capability

## Maintenance & Support

### Monitoring Tools
- Application: DataDog/NewRelic
- Errors: Sentry
- Logs: ELK Stack
- Uptime: Pingdom

### Backup Strategy
- Database: Daily snapshots
- Files: S3 versioning
- Code: Git with tags
- Config: Encrypted backups

### Update Process
- Blue-green deployments
- Database migrations versioned
- Rollback procedures
- Feature flags for gradual rollout

---

**Implementation Ready**: All 9 API services are fully documented with detailed dataflows for backend implementation. Follow the sprint plan for systematic development.