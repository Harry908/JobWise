# 02 - Profile API Service

**Version**: 3.0  
**Base Path**: `/api/v1/profiles`  
**Status**: Enhanced Fields Design  
**Service Type**: Synchronous CRUD Operations

## Service Overview

Manages master resume profiles with AI-enhanced descriptions. Supports both original and enhanced versions with version rotation for comparison.

## Database Schema

### MasterProfileModel
```sql
CREATE TABLE master_profiles (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL UNIQUE,
    personal_info JSONB NOT NULL,
    professional_summary TEXT,
    enhanced_summary TEXT,
    previous_enhanced_summary TEXT,
    skills JSONB,
    custom_fields JSONB,
    enhancement_version INTEGER DEFAULT 0,
    last_enhanced_at DATETIME,
    enhancement_status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

## API Endpoints with Detailed Dataflow

### 1. POST /profiles - Create Profile

**Dataflow Implementation:**
```
Step 1: Request Validation
- Extract JWT from Authorization header
- Decode JWT to get user_id
- Parse request body JSON

Step 2: Business Logic Validation
- Query: SELECT id FROM master_profiles WHERE user_id = ?
- If exists, return 409 Conflict
- Validate personal_info.full_name (required, 1-100 chars)
- Validate personal_info.email (required, valid email)

Step 3: Data Preparation
- Generate profile_id using UUID
- Generate IDs for experiences/projects if not provided
- Format dates to ISO 8601

Step 4: Database Transaction
BEGIN TRANSACTION;
- INSERT INTO master_profiles (id, user_id, personal_info, professional_summary, skills)
- For each experience:
  INSERT INTO experiences (id, profile_id, title, company, description, ...)
- For each project:
  INSERT INTO projects (id, profile_id, name, description, ...)
- For each education:
  INSERT INTO education (id, profile_id, institution, degree, ...)
COMMIT;

Step 5: Response
- Query complete profile with all relations
- Format response JSON
- Return 201 Created
```

### 2. GET /profiles/me - Get Current User Profile

**Dataflow Implementation:**
```
Step 1: Authentication
- Extract JWT from Authorization header
- Decode JWT to get user_id
- If invalid, return 401 Unauthorized

Step 2: Database Query
- Main query:
  SELECT * FROM master_profiles WHERE user_id = ?
- If not found, return 404

Step 3: Load Relations
- SELECT * FROM experiences WHERE profile_id = ? ORDER BY start_date DESC
- SELECT * FROM projects WHERE profile_id = ? ORDER BY start_date DESC
- SELECT * FROM education WHERE profile_id = ? ORDER BY start_date DESC

Step 4: Response Assembly
- Combine all data into nested structure
- Include both original and enhanced fields
- Add enhancement_metadata object
- Return 200 OK
```

### 3. PUT /profiles/{id} - Update Profile

**Dataflow Implementation:**
```
Step 1: Authorization
- Extract JWT and get user_id
- Query: SELECT user_id FROM master_profiles WHERE id = ?
- If profile.user_id != jwt.user_id, return 403

Step 2: Validation
- Validate all provided fields
- Check date logic (start_date < end_date)
- Validate URLs if provided

Step 3: Update Logic
BEGIN TRANSACTION;
- UPDATE master_profiles SET ... WHERE id = ?
- Handle experiences:
  * Delete removed: DELETE FROM experiences WHERE id IN (removed_ids)
  * Update existing: UPDATE experiences SET ... WHERE id = ?
  * Insert new: INSERT INTO experiences ...
- Same logic for projects and education
- UPDATE master_profiles SET updated_at = NOW()
COMMIT;

Step 4: Response
- Query updated profile
- Return 200 OK with full profile
```

### 4. PUT /profiles/{id}/preferences - Update Enhancement Preferences

**Dataflow Implementation:**
```
Step 1: Authorization
- Extract JWT and verify ownership

Step 2: Process Preferences
- Parse use_enhanced_summary boolean
- Parse experiences array [{id, use_enhanced}]
- Parse projects array [{id, use_enhanced}]

Step 3: Database Updates
BEGIN TRANSACTION;
- For each experience:
  UPDATE experiences SET use_enhanced = ? WHERE id = ? AND profile_id = ?
- For each project:
  UPDATE projects SET use_enhanced = ? WHERE id = ? AND profile_id = ?
- Track update count
COMMIT;

Step 4: Response
- Return 200 OK with update counts
```

### 5. GET /profiles/{id}/enhancement-history

**Dataflow Implementation:**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Query History
- SELECT enhancement_version, last_enhanced_at, enhancement_status 
  FROM master_profiles WHERE id = ?
- COUNT enhanced fields that are NOT NULL

Step 3: Build History
- Check if previous_enhanced_* fields exist
- Calculate changes between versions
- Format timeline

Step 4: Response
- Return enhancement history with version details
```

### 6. DELETE /profiles/{id}

**Dataflow Implementation:**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Delete (CASCADE handles relations)
DELETE FROM master_profiles WHERE id = ?

Step 3: Response
- Return 204 No Content
```

## Enhancement Field Management

### When Enhancement Occurs (Called by Enhancement Service)

**Dataflow:**
```
Step 1: Load Current State
- SELECT enhancement_version FROM master_profiles WHERE id = ?

Step 2: Apply Rotation Logic
If version = 0 (first enhancement):
  - UPDATE SET enhanced_summary = new_content
  - Leave previous_enhanced_summary NULL
  
If version = 1 (second enhancement):
  - UPDATE SET previous_enhanced_summary = enhanced_summary
  - UPDATE SET enhanced_summary = new_content
  
If version >= 2 (third+):
  - UPDATE SET previous_enhanced_summary = enhanced_summary  
  - UPDATE SET enhanced_summary = new_content
  - First version is discarded

Step 3: Update Metadata
- UPDATE SET enhancement_version = version + 1
- UPDATE SET last_enhanced_at = NOW()
- UPDATE SET enhancement_status = 'completed'
```

## Error Response Standards

| Code | Scenario | Response Body |
|------|----------|---------------|
| 400 | Invalid request format | `{"error": "Invalid request", "details": {...}}` |
| 401 | No/invalid JWT | `{"error": "Unauthorized"}` |
| 403 | Not owner | `{"error": "Forbidden", "message": "Not profile owner"}` |
| 404 | Profile not found | `{"error": "Profile not found"}` |
| 409 | Profile exists | `{"error": "Profile already exists"}` |
| 422 | Validation failed | `{"error": "Validation failed", "fields": {...}}` |