# 03 - Job API Service

**Version**: 2.1  
**Base Path**: `/api/v1/jobs`  
**Status**: Implemented  
**Service Type**: Synchronous CRUD with Text Parsing

## Service Overview

Manages job descriptions from multiple sources. Accepts raw text (auto-parsed) or structured data.

## Database Schema

### JobModel
```sql
CREATE TABLE jobs (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    source TEXT NOT NULL,
    title TEXT NOT NULL,
    company TEXT NOT NULL,
    location TEXT,
    description TEXT,
    raw_text TEXT,
    parsed_keywords TEXT,
    requirements TEXT,
    benefits TEXT,
    salary_range TEXT,
    remote BOOLEAN DEFAULT 0,
    status TEXT DEFAULT 'active',
    application_status TEXT DEFAULT 'not_applied',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

## API Endpoints with Detailed Dataflow

### 1. POST /jobs - Create Job (Raw Text)

**Dataflow Implementation:**
```
Step 1: Authentication & Validation
- Extract JWT to get user_id
- Check if raw_text or structured data provided

Step 2A: Raw Text Processing Path
If raw_text provided:
- Validate raw_text length (50-15000 chars)
- Apply regex patterns to extract:
  * Title: Match patterns like "Position:", "Title:", "Role:"
  * Company: Match "Company:", "Employer:", or after title
  * Location: Match "Location:", city/state patterns, "Remote"
  * Requirements: Match bullet points after "Requirements:", "Qualifications:"
  * Benefits: Match after "Benefits:", "Perks:", "We offer:"
- Extract keywords using frequency analysis:
  * Technical terms (Python, AWS, Docker, etc.)
  * Soft skills (leadership, communication, etc.)
  * Filter stop words
  * Deduplicate and lowercase

Step 2B: Structured Data Path
If structured data provided:
- Validate required fields (title, company)
- Extract keywords from description
- Parse requirements/benefits arrays

Step 3: Database Insert
- Generate job_id (UUID)
- INSERT INTO jobs (
    id, user_id, source, title, company, location,
    description, raw_text, parsed_keywords, requirements,
    benefits, salary_range, remote, status
  )
- Store parsed_keywords as JSON array
- Store requirements as JSON array
- Store benefits as JSON array

Step 4: Response
- Return 201 Created with parsed job data
```

### 2. GET /jobs - List User Jobs

**Dataflow Implementation:**
```
Step 1: Authentication
- Extract JWT to get user_id

Step 2: Parse Query Parameters
- status: 'active', 'archived', 'draft'
- source: 'user_created', 'indeed', 'linkedin'
- application_status: 'not_applied', 'applied', etc.
- limit: 1-100 (default 20)
- offset: pagination offset

Step 3: Build Query
SELECT * FROM jobs 
WHERE user_id = ?
  AND (status = ? OR status IS NULL)
  AND (source = ? OR source IS NULL)
  AND (application_status = ? OR application_status IS NULL)
ORDER BY created_at DESC
LIMIT ? OFFSET ?

Step 4: Count Total
SELECT COUNT(*) FROM jobs WHERE user_id = ? AND [filters]

Step 5: Response
- Return job list with pagination metadata
```

### 3. GET /jobs/{id} - Get Job Details

**Dataflow Implementation:**
```
Step 1: Authentication
- Extract JWT to get user_id

Step 2: Query Job
SELECT * FROM jobs WHERE id = ?

Step 3: Authorization Check
- If job.user_id != jwt.user_id, return 403

Step 4: Response
- Return complete job object
- Include parsed_keywords as array
- Include requirements as array
```

### 4. PUT /jobs/{id} - Update Job

**Dataflow Implementation:**
```
Step 1: Authorization
- Extract JWT and verify ownership
- SELECT user_id FROM jobs WHERE id = ?
- If not owner, return 403

Step 2: Validation
- Validate any provided fields
- If description changed, re-extract keywords

Step 3: Update
UPDATE jobs SET
  title = COALESCE(?, title),
  company = COALESCE(?, company),
  location = COALESCE(?, location),
  description = COALESCE(?, description),
  status = COALESCE(?, status),
  application_status = COALESCE(?, application_status),
  updated_at = NOW()
WHERE id = ?

Step 4: Keyword Re-extraction (if needed)
If description was updated:
- Extract new keywords
- UPDATE jobs SET parsed_keywords = ?

Step 5: Response
- Return updated job object
```

### 5. DELETE /jobs/{id} - Delete Job

**Dataflow Implementation:**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Hard Delete
DELETE FROM jobs WHERE id = ? AND user_id = ?

Step 3: Response
- Return 204 No Content
```

### 6. GET /jobs/browse - Browse Mock Jobs

**Dataflow Implementation:**
```
Step 1: Authentication
- Verify JWT (required for consistency)

Step 2: Parse Query Parameters
- query: search term
- location: filter by location
- remote: boolean filter
- limit: pagination limit
- offset: pagination offset

Step 3: Load Mock Data
- Read from mock_jobs.json file or database seed

Step 4: Apply Filters
- Filter by query (search in title, description, keywords)
- Filter by location (exact or contains)
- Filter by remote flag

Step 5: Paginate
- Apply limit and offset
- Calculate total count

Step 6: Response
- Return filtered mock jobs with pagination
```

## Text Parsing Details

### Title Extraction Patterns
```
Regex patterns to use:
- /(?:Position|Title|Role|Job):\s*(.+)/i
- /^([A-Z][^.!?\n]{10,60})$/m (first prominent line)
```

### Company Extraction Patterns
```
Regex patterns to use:
- /(?:Company|Employer|Organization):\s*(.+)/i
- /(?:at|with|join)\s+([A-Z][A-Za-z\s&,.-]+)/i
```

### Location Extraction Patterns
```
Regex patterns to use:
- /(?:Location|Based in|Office):\s*(.+)/i
- /([A-Z][a-z]+,\s*[A-Z]{2})/  (City, ST format)
- /\b(Remote|Hybrid|On-site)\b/i
```

### Keyword Extraction Algorithm
```
Step 1: Tokenize text (split by whitespace and punctuation)
Step 2: Filter tokens:
- Length > 2 characters
- Not in stop words list
- Matches known tech terms list
Step 3: Count frequency
Step 4: Take top 50 by frequency
Step 5: Deduplicate and lowercase
```

## Error Response Standards

| Code | Scenario | Response Body |
|------|----------|---------------|
| 400 | Invalid raw_text | `{"error": "Raw text too short/long"}` |
| 401 | No JWT | `{"error": "Unauthorized"}` |
| 403 | Not owner | `{"error": "Cannot modify this job"}` |
| 404 | Job not found | `{"error": "Job not found"}` |
| 422 | Parse failed | `{"error": "Could not parse job text"}` |