# Generation API Service

**Version**: 2.0
**Base Path**: `/api/v1/generations`
**Status**: Redesigned for Text Generation
**Last Updated**: November 2025

## Service Overview

Manages AI-powered generation of resumes and cover letters in text format. Uses rankings for resume compilation and AI for cover letter generation.

## Specification

**Purpose**: Generate job-tailored resumes and cover letters
**Authentication**: Required (JWT)
**Output Format**: Plain text (database stored)
**Processing**: Resume (fast compilation), Cover Letter (AI generation)
**Future Support**: LaTeX, Markdown, HTML formats

## Database Schema Updates

### GenerationModel (generations table)

```
id TEXT PRIMARY KEY                    -- UUID
user_id INTEGER NOT NULL               -- Owner
job_id TEXT NOT NULL                   -- Target job
profile_id TEXT NOT NULL               -- Source profile
ranking_id TEXT                        -- Used ranking (for resumes)
document_type TEXT NOT NULL            -- 'resume' or 'cover_letter'
content_text TEXT NOT NULL             -- Generated text content
content_format TEXT DEFAULT 'plain'    -- 'plain', 'latex', 'markdown'
metadata JSONB NOT NULL                -- Generation metadata
generation_params JSONB                -- Custom prompts, constraints
created_at DATETIME DEFAULT CURRENT_TIMESTAMP

FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE
FOREIGN KEY (ranking_id) REFERENCES job_content_rankings(id)
```

**Metadata Structure** (stored in JSONB):
```json
{
  "ats_score": 0.87,
  "keyword_coverage": 0.92,
  "word_count": 423,
  "line_count": 45,
  "sections_included": ["summary", "experience", "projects", "skills"],
  "experiences_included": ["exp_123", "exp_456"],
  "projects_included": ["proj_789"],
  "generation_time_ms": 1250,
  "ai_model_used": "llama-3.3-70b"
}
```

## Data Flow

### Resume Generation (Logic-Based)
```
1. Client → POST /generations/resume/text {job_id, format}
2. API validates JWT → get user_id
3. API fetches job and profile
4. API fetches or creates ranking for job
5. API compiles resume using pure logic:
   - Apply ranking order to experiences/projects
   - Include only items marked for inclusion
   - Use enhanced descriptions if selected
   - Apply bullet point reordering
   - Format sections according to sample structure
6. API stores generated text in database
7. API ← Generated resume text and metadata
```

### Cover Letter Generation (AI-Based)
```
1. Client → POST /generations/cover-letter/text {job_id}
2. API validates JWT → get user_id
3. API fetches job, profile, and sample cover letter
4. API sends to LLM:
   - Sample cover letter (for style)
   - Job description
   - Enhanced profile content
   - Custom prompt (if provided)
5. LLM generates tailored cover letter
6. API stores generated text
7. API ← Generated cover letter
```

## API Contract

### POST /generations/resume/text

**Description**: Generate text resume for specific job

**Headers**: `Authorization: Bearer <token>`

**Request**:
```json
{
  "job_id": "job_789",
  "format": "plain",
  "options": {
    "use_ranking": true,
    "use_enhanced": true,
    "include_summary": true,
    "max_pages": 1,
    "custom_sections": []
  },
  "custom_prompt": "Emphasize leadership experience"
}
```

**Response** (201 Created):
```json
{
  "id": "gen_123",
  "document_type": "resume",
  "job_id": "job_789",
  "content": {
    "text": "JOHN DOE\nSoftware Engineer\nSeattle, WA | john@example.com | (555) 123-4567\n\nPROFESSIONAL SUMMARY\nSeasoned software architect with proven expertise in building scalable systems...\n\nEXPERIENCE\n\nSenior Software Engineer\nTech Corp | Seattle, WA | Jan 2021 - Present\n• Led team of 4 developers in microservices migration\n• Architected enterprise-grade OAuth 2.0 authentication system\n• Optimized API performance achieving 40% response time reduction\n\n...",
    "format": "plain",
    "sections": {
      "header": "JOHN DOE\nSoftware Engineer\nSeattle, WA...",
      "summary": "Seasoned software architect...",
      "experience": "Senior Software Engineer\n...",
      "projects": "Cloud Migration Platform\n...",
      "skills": "Technical: AWS, Python, Docker..."
    }
  },
  "metadata": {
    "word_count": 423,
    "line_count": 45,
    "estimated_pages": 1,
    "ats_score": 0.87,
    "keyword_coverage": 0.92,
    "sections_included": ["header", "summary", "experience", "projects", "skills"],
    "ranking_applied": true,
    "experiences_included": ["exp_123", "exp_456"],
    "projects_included": ["proj_789"]
  },
  "download_url": "/api/v1/generations/gen_123/download.txt",
  "created_at": "2025-11-19T12:00:00Z"
}
```

**Error Responses**:
- 400: Invalid request parameters
- 401: Unauthorized
- 404: Job or profile not found
- 422: Generation failed

### POST /generations/cover-letter/text

**Description**: Generate AI cover letter for specific job

**Headers**: `Authorization: Bearer <token>`

**Request**:
```json
{
  "job_id": "job_789",
  "options": {
    "tone": "professional",
    "length": "medium",
    "include_salary_discussion": false
  },
  "custom_prompt": "Mention remote work experience and async collaboration"
}
```

**Response** (201 Created):
```json
{
  "id": "gen_456",
  "document_type": "cover_letter",
  "job_id": "job_789",
  "content": {
    "text": "Dear Hiring Manager,\n\nI am writing to express my strong interest in the Senior Software Engineer position at Tech Corp. With over 5 years of experience architecting scalable systems and leading distributed teams, I am excited about the opportunity to contribute to your cloud infrastructure initiatives.\n\nIn my current role at CurrentCo, I have architected enterprise-grade authentication systems and led successful microservices migrations, directly aligning with your requirements for cloud architecture expertise. My experience includes extensive remote collaboration with globally distributed teams, utilizing async communication patterns that maximize productivity across time zones.\n\n...\n\nSincerely,\nJohn Doe",
    "format": "plain",
    "paragraphs": [
      "Dear Hiring Manager,\n\nI am writing to express...",
      "In my current role at CurrentCo...",
      "I am particularly drawn to Tech Corp's...",
      "Thank you for considering...",
      "Sincerely,\nJohn Doe"
    ]
  },
  "metadata": {
    "word_count": 350,
    "paragraph_count": 5,
    "ai_model": "llama-3.3-70b",
    "generation_time_ms": 3500,
    "style_match_score": 0.91,
    "job_alignment_score": 0.88
  },
  "download_url": "/api/v1/generations/gen_456/download.txt",
  "created_at": "2025-11-19T12:05:00Z"
}
```

### GET /generations

**Description**: List user's generated documents

**Headers**: `Authorization: Bearer <token>`

**Query Parameters**:
- `document_type`: string ('resume', 'cover_letter')
- `job_id`: string
- `created_after`: ISO 8601 datetime
- `limit`: integer (1-100, default: 20)
- `offset`: integer (default: 0)

**Response** (200 OK):
```json
{
  "generations": [
    {
      "id": "gen_123",
      "document_type": "resume",
      "job_title": "Senior Software Engineer",
      "company": "Tech Corp",
      "created_at": "2025-11-19T12:00:00Z",
      "word_count": 423,
      "ats_score": 0.87
    },
    {
      "id": "gen_456",
      "document_type": "cover_letter",
      "job_title": "Senior Software Engineer",
      "company": "Tech Corp",
      "created_at": "2025-11-19T12:05:00Z",
      "word_count": 350
    }
  ],
  "pagination": {
    "total": 25,
    "limit": 20,
    "offset": 0
  }
}
```

### GET /generations/{id}

**Description**: Get specific generation details

**Headers**: `Authorization: Bearer <token>`

**Response** (200 OK): Same as creation response

### GET /generations/{id}/download.txt

**Description**: Download generation as text file

**Headers**: `Authorization: Bearer <token>`

**Response** (200 OK):
- Content-Type: text/plain
- Content-Disposition: attachment; filename="john_doe_resume.txt"
- Body: Plain text content

### DELETE /generations/{id}

**Description**: Delete a generation

**Headers**: `Authorization: Bearer <token>`

**Response** (204 No Content)

### GET /generations/{id}/formats

**Description**: Get available format conversions

**Headers**: `Authorization: Bearer <token>`

**Response** (200 OK):
```json
{
  "current_format": "plain",
  "available_formats": [
    {
      "format": "latex",
      "url": "/api/v1/generations/gen_123/convert/latex",
      "preview": "\\documentclass{article}\n\\begin{document}..."
    },
    {
      "format": "markdown",
      "url": "/api/v1/generations/gen_123/convert/markdown",
      "preview": "# John Doe\n## Software Engineer\n..."
    },
    {
      "format": "html",
      "url": "/api/v1/generations/gen_123/convert/html",
      "preview": "<html><head>...</head><body>..."
    }
  ]
}
```

### POST /generations/{id}/convert/{format}

**Description**: Convert generation to different format

**Headers**: `Authorization: Bearer <token>`

**Response** (200 OK):
```json
{
  "id": "gen_123_latex",
  "original_id": "gen_123",
  "format": "latex",
  "content": {
    "text": "\\documentclass{article}\n\\usepackage{...",
    "format": "latex"
  },
  "download_url": "/api/v1/generations/gen_123_latex/download.tex"
}
```

## Resume Compilation Logic

### Section Order (from sample analysis)
1. Header (name, contact)
2. Professional Summary (if included)
3. Experience (ranked and filtered)
4. Projects (ranked and filtered)
5. Education
6. Skills (prioritized)
7. Additional sections (if any)

### Text Formatting Rules
- Consistent spacing between sections
- Bullet points with "• " prefix
- Date format: "MMM YYYY" or "MMM YYYY - Present"
- Line length: max 80 characters for readability
- Section headers in CAPS

### Content Selection
- Use enhanced descriptions if `use_enhanced=true`
- Apply ranking from job_content_rankings
- Include only items with `include=true`
- Apply bullet point reordering per ranking
- Respect max_pages constraint

## Cover Letter Generation Prompts

### Base Prompt Structure
```
Using the following writing style from the sample cover letter:
[SAMPLE_COVER_LETTER]

Write a cover letter for this position:
[JOB_DESCRIPTION]

Using this candidate profile:
[ENHANCED_PROFILE]

Requirements:
- Match the tone and style of the sample
- Address specific job requirements
- Highlight relevant experiences
- Maintain authenticity
- Length: [LENGTH_PREFERENCE]
```

## Mobile Integration Notes

### Generation UI
- Show progress indicator during generation
- Display preview before saving
- Allow quick edits to generated text
- Provide format selection options

### Offline Handling
- Queue generation requests when offline
- Cache previous generations locally
- Sync when connection restored

### Text Display
- Monospace font for proper alignment
- Preserve formatting and spacing
- Allow copy to clipboard
- Export to device storage