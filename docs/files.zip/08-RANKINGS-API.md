# Rankings API Service

**Version**: 1.0
**Base Path**: `/api/v1/rankings`
**Status**: New Design
**Last Updated**: November 2025

## Service Overview

Manages job-specific content rankings for resume generation. AI analyzes job descriptions and ranks/reorders profile components (experiences, projects, skills) based on relevance.

## Specification

**Purpose**: AI-powered content ranking and ordering for job-specific resume tailoring
**Authentication**: Required (JWT)
**Processing**: Synchronous (3-5 seconds typical)
**Storage**: Rankings stored per job for reuse

## Database Schema

### JobContentRankingModel (job_content_rankings table)

```
id TEXT PRIMARY KEY                    -- UUID
user_id INTEGER NOT NULL               -- Owner
job_id TEXT NOT NULL                   -- Target job
profile_id TEXT NOT NULL               -- Source profile
ranking_data JSONB NOT NULL           -- Complete ranking results
created_at DATETIME DEFAULT CURRENT_TIMESTAMP
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
UNIQUE(user_id, job_id)               -- One ranking per job per user

FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE
```

**Ranking Data Structure** (stored in JSONB):
```json
{
  "experiences": [
    {
      "id": "exp_123",
      "relevance_score": 95,
      "include": true,
      "bullet_points_order": [2, 0, 1],
      "rationale": "Direct match with required backend skills"
    }
  ],
  "projects": [
    {
      "id": "proj_456",
      "relevance_score": 88,
      "include": true,
      "bullet_points_order": [1, 0, 2, 3],
      "rationale": "Demonstrates cloud architecture expertise"
    }
  ],
  "skills": {
    "ordered_list": ["Python", "AWS", "Docker", "PostgreSQL"],
    "excluded_for_space": []
  },
  "recommended_length": {
    "experiences_count": 3,
    "projects_count": 2,
    "constraint_applied": false,
    "rationale": "Optimal for single-page resume"
  }
}
```

## Data Flow

### Create Ranking for Job
```
1. Client → POST /rankings/create {job_id, constraints}
2. API validates JWT → get user_id
3. API fetches job details and user profile
4. API checks for existing ranking (return if fresh)
5. API sends to LLM:
   - Job description and requirements
   - User's enhanced profile content
   - Constraint preferences (if any)
6. LLM analyzes and returns:
   - Relevance scores for each component
   - Reordered bullet points
   - Inclusion recommendations
   - Skills prioritization
7. API stores ranking in database
8. API ← Ranking results
```

### Get Existing Ranking
```
1. Client → GET /rankings/{job_id}
2. API validates JWT → get user_id
3. API fetches ranking for job_id + user_id
4. API returns cached ranking
```

## API Contract

### POST /rankings/create

**Description**: Create or update ranking for specific job

**Headers**: `Authorization: Bearer <token>`

**Request**:
```json
{
  "job_id": "job_789",
  "constraints": {
    "max_experiences": 3,
    "max_projects": 2,
    "target_length": "one_page",
    "enforce_limits": false
  },
  "custom_prompt": "Emphasize cloud architecture and team leadership",
  "force_refresh": false
}
```

**Response** (201 Created):
```json
{
  "id": "rank_567",
  "job_id": "job_789",
  "profile_id": "prof_123",
  "ranking": {
    "experiences": [
      {
        "id": "exp_123",
        "title": "Senior Software Engineer",
        "company": "Tech Corp",
        "relevance_score": 95,
        "include": true,
        "bullet_points_order": [2, 0, 1],
        "original_bullets": [
          "• Built OAuth 2.0 authentication",
          "• Reduced API response time by 40%",
          "• Led team of 4 developers"
        ],
        "reordered_bullets": [
          "• Led team of 4 developers",
          "• Built OAuth 2.0 authentication",
          "• Reduced API response time by 40%"
        ],
        "rationale": "Leadership experience matches job requirement"
      },
      {
        "id": "exp_456",
        "relevance_score": 70,
        "include": true,
        "bullet_points_order": [1, 0, 2]
      },
      {
        "id": "exp_789",
        "relevance_score": 40,
        "include": false,
        "rationale": "Less relevant to cloud architecture focus"
      }
    ],
    "projects": [
      {
        "id": "proj_123",
        "name": "Cloud Migration",
        "relevance_score": 92,
        "include": true,
        "bullet_points_order": [0, 2, 1],
        "rationale": "Perfect match for cloud expertise requirement"
      }
    ],
    "skills": {
      "ordered_list": ["AWS", "Kubernetes", "Python", "Team Leadership", "Terraform"],
      "excluded_for_space": ["Eclipse", "MIPS"],
      "relevance_map": {
        "AWS": 100,
        "Kubernetes": 95,
        "Python": 90,
        "Team Leadership": 88
      }
    },
    "recommended_length": {
      "experiences_count": 3,
      "projects_count": 2,
      "constraint_applied": false,
      "estimated_lines": 45,
      "rationale": "Fits one-page format with optimal content"
    }
  },
  "metadata": {
    "created_at": "2025-11-19T11:00:00Z",
    "job_match_score": 0.87,
    "keyword_coverage": 0.92
  }
}
```

**Error Responses**:
- 400: Invalid job_id or constraints
- 401: Unauthorized
- 404: Job or profile not found
- 409: Ranking in progress (if async in future)

### GET /rankings/{job_id}

**Description**: Get existing ranking for job

**Headers**: `Authorization: Bearer <token>`

**Response** (200 OK):
```json
{
  "id": "rank_567",
  "job_id": "job_789",
  "ranking": { ... },
  "metadata": {
    "created_at": "2025-11-19T11:00:00Z",
    "is_stale": false,
    "staleness_reason": null
  }
}
```

**Response** (404 Not Found):
```json
{
  "error": "No ranking found for this job",
  "suggestion": "Create ranking using POST /rankings/create"
}
```

### GET /rankings

**Description**: List all user's rankings

**Headers**: `Authorization: Bearer <token>`

**Query Parameters**:
- `limit`: integer (1-100, default: 20)
- `offset`: integer (default: 0)
- `include_stale`: boolean (default: true)

**Response** (200 OK):
```json
{
  "rankings": [
    {
      "id": "rank_567",
      "job_id": "job_789",
      "job_title": "Senior Python Developer",
      "company": "Tech Corp",
      "created_at": "2025-11-19T11:00:00Z",
      "match_score": 0.87,
      "is_stale": false
    },
    {
      "id": "rank_234",
      "job_id": "job_456",
      "job_title": "Full Stack Engineer",
      "company": "StartupCo",
      "created_at": "2025-11-18T15:00:00Z",
      "match_score": 0.75,
      "is_stale": true,
      "staleness_reason": "Profile updated after ranking"
    }
  ],
  "pagination": {
    "total": 15,
    "limit": 20,
    "offset": 0
  }
}
```

### DELETE /rankings/{job_id}

**Description**: Delete ranking for job

**Headers**: `Authorization: Bearer <token>`

**Response** (204 No Content)

**Error Responses**:
- 401: Unauthorized
- 403: User doesn't own ranking
- 404: Ranking not found

### POST /rankings/{job_id}/refresh

**Description**: Force refresh existing ranking

**Headers**: `Authorization: Bearer <token>`

**Request**:
```json
{
  "reason": "Profile updated",
  "custom_prompt": "Focus more on technical skills"
}
```

**Response** (200 OK): Same as POST /create response

## Ranking Algorithm

### Relevance Scoring Factors
1. **Keyword Match** (40%): Direct keyword matches between job and experience
2. **Skill Alignment** (30%): Required skills present in experience/project
3. **Industry Relevance** (20%): Same or related industry experience
4. **Recency** (10%): More recent experiences weighted higher

### Bullet Point Reordering Logic
1. Identify key requirements from job description
2. Score each bullet point against requirements
3. Order by relevance score (highest first)
4. Maintain logical flow and readability

### Inclusion Decision Process
```
if relevance_score >= 70:
    include = True
elif available_space and relevance_score >= 40:
    include = True
else:
    include = False
```

## Staleness Detection

Rankings become stale when:
- Profile updated after ranking created
- Job description edited after ranking
- More than 30 days old
- User requests refresh

Stale rankings are marked but not auto-deleted, allowing user to decide on refresh.

## Mobile Integration Notes

### Ranking UI
- Show match percentage for each job
- Display included/excluded components
- Preview reordered content
- Allow manual override of inclusions

### Performance Optimization
- Cache rankings locally
- Background refresh stale rankings
- Show cached while refreshing
- Progressive loading for large profiles

### User Controls
- Toggle constraint enforcement
- Adjust target resume length
- Override AI recommendations
- Manual reordering option