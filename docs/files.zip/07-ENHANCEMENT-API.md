# Enhancement API Service

**Version**: 1.0
**Base Path**: `/api/v1/enhancement`
**Status**: New Design
**Last Updated**: November 2025

## Service Overview

Manages AI-powered profile enhancement using writing styles extracted from sample documents. Enhances all profile components (summary, experiences, projects) in a single operation.

## Specification

**Purpose**: AI enhancement of profile descriptions using extracted writing styles
**Authentication**: Required (JWT)
**Processing**: Asynchronous with status tracking
**Enhancement Scope**: All components enhanced together (no partial enhancement)
**History**: Maintains current + previous enhanced versions

## Data Flow

### Trigger Enhancement
```
1. Client → POST /enhancement/trigger
2. API validates JWT → get user_id
3. API validates prerequisites:
   - User has profile with content
   - User has uploaded both sample documents
   - Style extraction completed on samples
4. API creates enhancement job
5. API queues async enhancement tasks:
   - Extract writing style from cover letter
   - Extract structure patterns from resume
   - Enhance profile summary
   - Enhance all experience descriptions
   - Enhance all project descriptions
6. API ← Job ID and status URL
```

### Enhancement Processing (Async)
```
1. Worker fetches enhancement job
2. Worker loads user's samples and profile
3. Worker calls LLM for style extraction
4. Worker enhances each component:
   - Preserves factual content
   - Applies extracted writing style
   - Follows resume structure patterns
5. Worker implements rotation logic:
   - If 3rd enhancement: previous = current
   - current = new enhanced version
6. Worker updates database with enhanced text
7. Worker updates enhancement_status = 'completed'
```

### Check Enhancement Status
```
1. Client → GET /enhancement/status
2. API validates JWT → get user_id
3. API fetches latest enhancement job
4. API returns progress and completion status
```

## API Contract

### POST /enhancement/trigger

**Description**: Start AI enhancement of entire profile

**Headers**: `Authorization: Bearer <token>`

**Request** (optional):
```json
{
  "custom_prompt": "Focus on leadership and technical innovation",
  "emphasis": {
    "technical_depth": true,
    "metrics": true,
    "team_collaboration": false
  }
}
```

**Response** (202 Accepted):
```json
{
  "job_id": "enh_job_789",
  "status": "processing",
  "status_url": "/api/v1/enhancement/status",
  "components_to_enhance": {
    "professional_summary": true,
    "experiences_count": 3,
    "projects_count": 2
  },
  "estimated_completion_time": 30,
  "message": "Enhancement started. Check status for progress."
}
```

**Error Responses**:
- 400: Missing prerequisites (no profile or samples)
- 401: Unauthorized
- 404: Profile not found
- 409: Enhancement already in progress
- 412: Samples not yet analyzed (style extraction pending)

### GET /enhancement/status

**Description**: Check enhancement job status

**Headers**: `Authorization: Bearer <token>`

**Response** (200 OK) - In Progress:
```json
{
  "job_id": "enh_job_789",
  "status": "processing",
  "progress": {
    "total_steps": 6,
    "completed_steps": 3,
    "current_step": "enhancing_experiences",
    "percentage": 50
  },
  "components_status": {
    "style_extraction": "completed",
    "professional_summary": "completed",
    "experiences": "processing",
    "projects": "pending"
  },
  "started_at": "2025-11-19T10:30:00Z",
  "estimated_remaining_time": 15
}
```

**Response** (200 OK) - Completed:
```json
{
  "job_id": "enh_job_789",
  "status": "completed",
  "progress": {
    "total_steps": 6,
    "completed_steps": 6,
    "percentage": 100
  },
  "results": {
    "enhanced_count": {
      "professional_summary": 1,
      "experiences": 3,
      "projects": 2
    },
    "enhancement_version": 2,
    "sample_version_used": 1
  },
  "completed_at": "2025-11-19T10:31:30Z",
  "duration_seconds": 90
}
```

**Response** (200 OK) - Failed:
```json
{
  "job_id": "enh_job_789",
  "status": "failed",
  "error": {
    "code": "LLM_ERROR",
    "message": "Failed to process enhancement",
    "failed_at_step": "enhancing_experiences",
    "retry_available": true
  },
  "failed_at": "2025-11-19T10:30:45Z"
}
```

### GET /enhancement/history

**Description**: Get enhancement history for user

**Headers**: `Authorization: Bearer <token>`

**Response** (200 OK):
```json
{
  "enhancements": [
    {
      "job_id": "enh_job_789",
      "version": 2,
      "status": "completed",
      "sample_versions": {
        "resume_sample": 1,
        "cover_letter_sample": 1
      },
      "enhanced_components": {
        "professional_summary": true,
        "experiences": 3,
        "projects": 2
      },
      "completed_at": "2025-11-19T10:31:30Z"
    },
    {
      "job_id": "enh_job_456",
      "version": 1,
      "status": "completed",
      "completed_at": "2025-11-18T14:20:00Z"
    }
  ],
  "current_version": 2,
  "can_compare": true
}
```

### POST /enhancement/retry

**Description**: Retry failed enhancement

**Headers**: `Authorization: Bearer <token>`

**Request**:
```json
{
  "job_id": "enh_job_789"
}
```

**Response** (202 Accepted):
```json
{
  "job_id": "enh_job_790",
  "status": "processing",
  "retry_of": "enh_job_789",
  "message": "Enhancement retry started"
}
```

### GET /enhancement/comparison

**Description**: Get side-by-side comparison of original, current, and previous enhanced versions

**Headers**: `Authorization: Bearer <token>`

**Response** (200 OK):
```json
{
  "professional_summary": {
    "original": "Experienced software engineer...",
    "current_enhanced": "Seasoned software architect with proven expertise...",
    "previous_enhanced": "Accomplished software engineer demonstrating..."
  },
  "experiences": [
    {
      "id": "exp_1",
      "title": "Senior Software Engineer",
      "original": "• Built OAuth 2.0 authentication",
      "current_enhanced": "• Architected enterprise-grade OAuth 2.0 authentication system",
      "previous_enhanced": "• Developed secure OAuth 2.0 authentication framework"
    }
  ],
  "projects": [
    {
      "id": "proj_1",
      "name": "E-commerce Platform",
      "original": "Built scalable platform",
      "current_enhanced": "Architected high-performance e-commerce platform supporting 10K+ concurrent users",
      "previous_enhanced": "Developed scalable e-commerce solution with microservices"
    }
  ]
}
```

## Enhancement Rules

### Rotation Logic
1. First enhancement: `enhanced_*` = new, `previous_enhanced_*` = null
2. Second enhancement: `previous_enhanced_*` = first, `enhanced_*` = new
3. Third+ enhancement: `previous_enhanced_*` = current, `enhanced_*` = new

### Content Preservation
- Never fabricate experiences or achievements
- Maintain all factual information
- Only enhance language, structure, and impact presentation
- Preserve technical accuracy

### Style Application Priority
1. Result emphasis patterns (from resume sample)
2. Metric inclusion patterns (from resume sample)
3. Action verb usage (from resume sample)
4. Tone and vocabulary (from cover letter sample)

## Error Handling

### Prerequisites Check
Before enhancement can start:
- User must have profile with content
- User must have uploaded resume sample
- User must have uploaded cover letter sample
- Style extraction must be completed on samples

### Failure Recovery
- Automatic retry for transient failures (up to 3 times)
- Manual retry available for permanent failures
- Partial enhancement rollback on critical errors
- Previous versions preserved during failures

## Mobile Integration Notes

### Enhancement UI Flow
1. Show enhancement eligibility status
2. Display prerequisites checklist
3. Provide "Enhance Profile" button when ready
4. Show real-time progress during enhancement
5. Notify on completion with comparison view

### Progress Tracking
- WebSocket connection for real-time updates
- Polling fallback every 5 seconds
- Show step-by-step progress
- Estimated time remaining display

### Comparison View
- Side-by-side comparison layout
- Highlight differences
- Toggle between versions
- Select which version to use for each component