# 04 - Sample Documents API Service

**Version**: 1.0  
**Base Path**: `/api/v1/samples`  
**Status**: New Design  
**Service Type**: File Upload with Text Extraction

## Service Overview

Manages user-uploaded sample documents (resume and cover letter) for AI style extraction. Each user maintains one active sample of each type.

## Database Schema

### SampleDocumentModel
```sql
CREATE TABLE sample_documents (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    document_type TEXT NOT NULL,
    file_name TEXT NOT NULL,
    file_path TEXT,
    full_text TEXT NOT NULL,
    extracted_style JSONB,
    version INTEGER DEFAULT 1,
    file_size_bytes INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, document_type),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

## API Endpoints with Detailed Dataflow

### 1. POST /samples/upload-resume - Upload Resume Sample

**Dataflow Implementation:**
```
Step 1: Request Processing
- Extract JWT to get user_id
- Receive multipart/form-data
- Extract file from request

Step 2: File Validation
- Check file extension (.txt, .pdf, .docx)
- Check file size (max 5MB)
- If invalid, return 400

Step 3: Text Extraction
For .txt files:
  - Read file directly as UTF-8 text
For .pdf files:
  - Use PyPDF2 library
  - Extract text from all pages
  - Concatenate with page breaks
For .docx files:
  - Use python-docx library
  - Extract paragraphs and tables
  - Format as plain text

Step 4: Content Validation
- Check extracted text length (min 100 chars)
- Check text is readable (not garbled)
- If extraction failed, return 422

Step 5: Check Existing Sample
- Query: SELECT id, version FROM sample_documents 
         WHERE user_id = ? AND document_type = 'resume_sample'
- If exists, increment version number

Step 6: File Storage
- Generate storage path: /uploads/{user_id}/resume_v{version}_{timestamp}.{ext}
- Save original file to filesystem
- Store path in database

Step 7: Database Operation
INSERT INTO sample_documents (
  id, user_id, document_type, file_name, file_path,
  full_text, version, file_size_bytes
) VALUES (?, ?, 'resume_sample', ?, ?, ?, ?, ?)
ON CONFLICT (user_id, document_type) 
DO UPDATE SET 
  file_name = EXCLUDED.file_name,
  file_path = EXCLUDED.file_path,
  full_text = EXCLUDED.full_text,
  version = version + 1,
  updated_at = NOW()

Step 8: Trigger Style Extraction (Async)
- Queue job: {type: 'extract_resume_style', sample_id: id}
- Job will update extracted_style field later

Step 9: Response
- Return 201 Created with sample metadata
- Include extraction status: 'pending'
```

### 2. POST /samples/upload-cover-letter - Upload Cover Letter Sample

**Dataflow Implementation:**
```
Step 1-4: Same as resume upload
- File validation (max 2MB for cover letter)
- Text extraction
- Content validation

Step 5: Check Existing Sample
- Query: SELECT id, version FROM sample_documents 
         WHERE user_id = ? AND document_type = 'cover_letter_sample'

Step 6-7: Storage and Database
- Storage path: /uploads/{user_id}/cover_letter_v{version}_{timestamp}.{ext}
- Insert or update with document_type = 'cover_letter_sample'

Step 8: Trigger Style Extraction (Async)
- Queue job: {type: 'extract_cover_letter_style', sample_id: id}

Step 9: Response
- Return 201 Created
```

### 3. GET /samples - Get User's Samples

**Dataflow Implementation:**
```
Step 1: Authentication
- Extract JWT to get user_id

Step 2: Query Samples
SELECT * FROM sample_documents 
WHERE user_id = ? 
ORDER BY document_type, version DESC

Step 3: Format Response
For each sample:
- Include full_text
- Include extracted_style if available
- Calculate extraction status:
  * If extracted_style IS NULL: 'pending'
  * If extracted_style IS NOT NULL: 'completed'

Step 4: Response
- Return array of samples
- Group by document_type for clarity
```

### 4. GET /samples/{id} - Get Specific Sample

**Dataflow Implementation:**
```
Step 1: Authorization
- Extract JWT to get user_id
- Query: SELECT * FROM sample_documents WHERE id = ?
- If sample.user_id != jwt.user_id, return 403

Step 2: Load Previous Versions
SELECT version, created_at FROM sample_documents
WHERE user_id = ? AND document_type = ?
ORDER BY version DESC

Step 3: Response
- Return sample with full details
- Include previous version history
```

### 5. DELETE /samples/{id} - Delete Sample

**Dataflow Implementation:**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Get File Path
SELECT file_path FROM sample_documents WHERE id = ?

Step 3: Delete File
- Remove file from filesystem if exists

Step 4: Delete Record
DELETE FROM sample_documents WHERE id = ?

Step 5: Response
- Return 204 No Content
```

### 6. POST /samples/{id}/reextract-style - Trigger Re-extraction

**Dataflow Implementation:**
```
Step 1: Authorization
- Verify JWT and ownership

Step 2: Queue Extraction Job
- Determine type from document_type field
- Queue appropriate extraction job

Step 3: Update Status
UPDATE sample_documents 
SET extracted_style = NULL 
WHERE id = ?

Step 4: Response
- Return 202 Accepted
- Include estimated completion time
```

## Style Extraction Process (Async Worker)

### Resume Style Extraction

**Dataflow:**
```
Step 1: Load Sample
- Query full_text from database

Step 2: Structure Analysis
- Identify section headers (EXPERIENCE, EDUCATION, etc.)
- Analyze bullet point patterns
- Count average words per bullet
- Identify metric usage frequency

Step 3: Pattern Extraction
Extract and store:
- Bullet format (verb_action_result vs action_result)
- Section ordering
- Date format patterns
- Technology listing style (inline vs separate)

Step 4: Store Results
UPDATE sample_documents 
SET extracted_style = ? 
WHERE id = ?

Structure stored:
{
  "structure": {
    "sections_order": ["experience", "projects", "education"],
    "bullet_format": "verb_action_result",
    "avg_bullet_length": 85,
    "metric_usage": "frequent"
  },
  "patterns": {
    "result_emphasis": "business_impact",
    "technology_listing": "inline",
    "date_format": "MMM YYYY"
  }
}
```

### Cover Letter Style Extraction

**Dataflow:**
```
Step 1: Load Sample
- Query full_text from database

Step 2: Vocabulary Analysis
- Extract unique words
- Categorize by complexity
- Identify industry terms
- Find common action verbs

Step 3: Tone Analysis
- Measure formality level
- Detect confidence indicators
- Identify personality markers

Step 4: Store Results
UPDATE sample_documents 
SET extracted_style = ?
WHERE id = ?

Structure stored:
{
  "vocabulary": {
    "complexity_level": "advanced",
    "common_verbs": ["architected", "optimized"],
    "industry_terms": ["scalable", "microservices"]
  },
  "tone": {
    "formality": "professional",
    "confidence_level": "high",
    "personality_markers": ["collaborative", "innovative"]
  }
}
```

## Text Extraction Libraries

### PDF Extraction
```python
# Using PyPDF2
import PyPDF2
reader = PyPDF2.PdfReader(file)
text = ""
for page in reader.pages:
    text += page.extract_text()
```

### DOCX Extraction
```python
# Using python-docx
import docx
doc = docx.Document(file)
text = "\n".join([para.text for para in doc.paragraphs])
```

## Error Response Standards

| Code | Scenario | Response Body |
|------|----------|---------------|
| 400 | Invalid file type | `{"error": "File type not supported"}` |
| 413 | File too large | `{"error": "File exceeds 5MB limit"}` |
| 422 | Extraction failed | `{"error": "Could not extract text"}` |
| 409 | Processing | `{"error": "Style extraction in progress"}` |