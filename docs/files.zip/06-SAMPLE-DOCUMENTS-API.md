# Sample Documents API Service

**Version**: 1.0
**Base Path**: `/api/v1/samples`
**Status**: New Design
**Last Updated**: November 2025

## Service Overview

Manages user-uploaded sample documents (resume and cover letter) used as templates for AI style extraction and generation. Each user can have one active sample of each type at any time.

## Specification

**Purpose**: Store and manage sample documents for AI writing style analysis
**Authentication**: Required (JWT)
**File Types Supported**: .txt, .pdf, .docx
**Storage**: Database (full text) + file system (original files)
**Limits**: 1 resume sample, 1 cover letter sample per user

## Database Schema

### SampleDocumentModel (sample_documents table)

```
id TEXT PRIMARY KEY                    -- UUID
user_id INTEGER NOT NULL               -- Owner
document_type TEXT NOT NULL            -- 'resume_sample' or 'cover_letter_sample'
file_name TEXT NOT NULL                -- Original filename
file_path TEXT                         -- Storage path for original file
full_text TEXT NOT NULL                -- Extracted text content
extracted_style JSONB                  -- AI-analyzed writing style
version INTEGER DEFAULT 1              -- Version number (increments on replacement)
file_size_bytes INTEGER                -- Original file size
created_at DATETIME DEFAULT CURRENT_TIMESTAMP
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
UNIQUE(user_id, document_type)        -- One sample per type per user

FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
```

**Extracted Style Structure** (stored in JSONB):
```json
{
  "vocabulary": {
    "complexity_level": "advanced",
    "common_verbs": ["architected", "optimized", "implemented"],
    "industry_terms": ["scalable", "enterprise-grade", "microservices"]
  },
  "structure": {
    "bullet_format": "verb_action_result",
    "avg_bullet_length": 85,
    "metric_usage": "frequent",
    "sections_order": ["experience", "projects", "education", "skills"]
  },
  "tone": {
    "formality": "professional",
    "confidence_level": "high",
    "personality_markers": ["collaborative", "results-driven"]
  },
  "patterns": {
    "result_emphasis": "business_impact",
    "technology_listing": "inline",
    "team_mentions": true
  }
}
```

## Data Flow

### Upload Sample Resume
```
1. Client → POST /samples/upload-resume with file
2. API validates JWT → get user_id
3. API validates file type and size (<5MB)
4. API extracts text from file (TXT/PDF/DOCX)
5. API checks for existing resume sample
   - If exists: increment version, store previous as history
6. API stores file in filesystem
7. API creates/updates sample_documents record
8. API triggers async style extraction (queued)
9. API ← Success response with sample ID
```

### Upload Sample Cover Letter
```
1. Client → POST /samples/upload-cover-letter with file
2. API validates JWT → get user_id
3. API validates file type and size (<2MB)
4. API extracts text from file
5. API checks for existing cover letter sample
   - If exists: increment version
6. API stores file and creates record
7. API triggers async style extraction
8. API ← Success response
```

### Get User Samples
```
1. Client → GET /samples
2. API validates JWT → get user_id
3. API fetches all samples for user
4. API returns samples with metadata
5. Client can view text and style analysis
```

## API Contract

### POST /samples/upload-resume

**Description**: Upload sample resume for style extraction

**Headers**: 
- `Authorization: Bearer <token>`
- `Content-Type: multipart/form-data`

**Request**: Multipart form data with file

**Response** (201 Created):
```json
{
  "id": "sample_123",
  "document_type": "resume_sample",
  "file_name": "john_doe_resume.txt",
  "version": 1,
  "file_size_bytes": 4521,
  "text_preview": "John Doe\nSoftware Engineer\n...",
  "created_at": "2025-11-19T10:00:00Z",
  "style_extraction_status": "pending"
}
```

**Error Responses**:
- 400: Invalid file type or file too large
- 401: Unauthorized
- 413: File size exceeds limit (5MB)
- 415: Unsupported media type
- 422: Failed to extract text from file

### POST /samples/upload-cover-letter

**Description**: Upload sample cover letter for style extraction

**Headers**: 
- `Authorization: Bearer <token>`
- `Content-Type: multipart/form-data`

**Request**: Multipart form data with file

**Response** (201 Created):
```json
{
  "id": "sample_456",
  "document_type": "cover_letter_sample",
  "file_name": "cover_letter.txt",
  "version": 1,
  "file_size_bytes": 2103,
  "text_preview": "Dear Hiring Manager,\n...",
  "created_at": "2025-11-19T10:05:00Z",
  "style_extraction_status": "pending"
}
```

### GET /samples

**Description**: Get all user's sample documents

**Headers**: `Authorization: Bearer <token>`

**Response** (200 OK):
```json
{
  "samples": [
    {
      "id": "sample_123",
      "document_type": "resume_sample",
      "file_name": "john_doe_resume.txt",
      "version": 2,
      "file_size_bytes": 4521,
      "full_text": "Complete resume text here...",
      "extracted_style": {
        "vocabulary": {
          "complexity_level": "advanced",
          "common_verbs": ["architected", "optimized"]
        },
        "structure": {
          "bullet_format": "verb_action_result",
          "sections_order": ["experience", "projects", "education"]
        }
      },
      "style_extraction_status": "completed",
      "created_at": "2025-11-19T10:00:00Z",
      "updated_at": "2025-11-19T10:30:00Z"
    },
    {
      "id": "sample_456",
      "document_type": "cover_letter_sample",
      "file_name": "cover_letter.txt",
      "version": 1,
      "full_text": "Complete cover letter text...",
      "extracted_style": {
        "tone": {
          "formality": "professional",
          "confidence_level": "high"
        }
      },
      "style_extraction_status": "completed",
      "created_at": "2025-11-19T10:05:00Z"
    }
  ]
}
```

### GET /samples/{id}

**Description**: Get specific sample document

**Headers**: `Authorization: Bearer <token>`

**Response** (200 OK):
```json
{
  "id": "sample_123",
  "document_type": "resume_sample",
  "file_name": "john_doe_resume.txt",
  "version": 2,
  "full_text": "Complete document text...",
  "extracted_style": { },
  "style_extraction_status": "completed",
  "previous_versions": [
    {
      "version": 1,
      "uploaded_at": "2025-11-18T09:00:00Z"
    }
  ]
}
```

### DELETE /samples/{id}

**Description**: Delete a sample document

**Headers**: `Authorization: Bearer <token>`

**Response** (204 No Content)

**Error Responses**:
- 401: Unauthorized
- 403: User doesn't own sample
- 404: Sample not found

### POST /samples/{id}/reextract-style

**Description**: Manually trigger style re-extraction

**Headers**: `Authorization: Bearer <token>`

**Response** (202 Accepted):
```json
{
  "message": "Style extraction queued",
  "estimated_time": 15
}
```

## Version Management

When user uploads new sample (same type):
1. Current sample version increments
2. Old file is archived (optional)
3. New text replaces old in database
4. Enhancement references update to new version
5. User notified to re-enhance profile if desired

## Validation Rules

**File Upload:**
- Resume max size: 5MB
- Cover letter max size: 2MB
- Supported formats: .txt, .pdf, .docx
- Text extraction required for processing

**Text Content:**
- Minimum 100 characters
- Maximum 50,000 characters
- Must be readable text (not images)

## Mobile Integration Notes

### File Upload Flow
- Use file picker to select document
- Show upload progress indicator
- Display extraction status
- Preview extracted text
- Show style analysis when complete

### Storage Optimization
- Cache extracted text locally
- Don't cache original files
- Sync style analysis on demand