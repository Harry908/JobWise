# 05 - Enhancement API Service

**Version**: 1.0  
**Base Path**: `/api/v1/enhancement`  
**Status**: New Design  
**Service Type**: Asynchronous AI Processing

## Service Overview

Manages AI-powered profile enhancement using writing styles extracted from sample documents. Enhances all components in a single operation.

## Database Schema

### EnhancementJobModel
```sql
CREATE TABLE enhancement_jobs (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    profile_id TEXT NOT NULL,
    status TEXT NOT NULL,
    progress INTEGER DEFAULT 0,
    current_step TEXT,
    sample_version_used INTEGER,
    error_message TEXT,
    started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (profile_id) REFERENCES master_profiles(id) ON DELETE CASCADE
);
```

## API Endpoints with Detailed Dataflow

### 1. POST /enhancement/trigger - Start Enhancement

**Dataflow Implementation:**
```
Step 1: Authentication & Validation
- Extract JWT to get user_id
- Parse optional custom_prompt and emphasis parameters

Step 2: Prerequisites Check
Query 1: Check profile exists with content
SELECT id, professional_summary, 
       (SELECT COUNT(*) FROM experiences WHERE profile_id = p.id) as exp_count,
       (SELECT COUNT(*) FROM projects WHERE profile_id = p.id) as proj_count
FROM master_profiles p WHERE user_id = ?

If no profile or no content, return 400

Query 2: Check samples exist and are analyzed
SELECT document_type, extracted_style, version 
FROM sample_documents 
WHERE user_id = ? 
AND document_type IN ('resume_sample', 'cover_letter_sample')

If count < 2 or any extracted_style IS NULL, return 412

Step 3: Check for Active Enhancement
SELECT id, status FROM enhancement_jobs 
WHERE user_id = ? AND status = 'processing'

If exists, return 409 Conflict

Step 4: Create Enhancement Job
- Generate job_id (UUID)
- INSERT INTO enhancement_jobs (
    id, user_id, profile_id, status, sample_version_used
  ) VALUES (?, ?, ?, 'processing', ?)

Step 5: Queue Async Tasks
Queue message: {
  job_id: id,
  user_id: user_id,
  tasks: [
    'extract_writing_style',
    'enhance_summary',
    'enhance_experiences',
    'enhance_projects'
  ],
  custom_prompt: custom_prompt,
  emphasis: emphasis
}

Step 6: Response
- Return 202 Accepted
- Include job_id and status_url
```

### 2. GET /enhancement/status - Check Progress

**Dataflow Implementation:**
```
Step 1: Authentication
- Extract JWT to get user_id

Step 2: Get Latest Job
SELECT * FROM enhancement_jobs 
WHERE user_id = ? 
ORDER BY started_at DESC 
LIMIT 1

Step 3: Calculate Progress
Based on current_step:
- 'extracting_style': 20%
- 'enhancing_summary': 40%
- 'enhancing_experiences': 60%
- 'enhancing_projects': 80%
- 'completed': 100%

Step 4: Response
Return status with progress details
```

### 3. GET /enhancement/history - Get History

**Dataflow Implementation:**
```
Step 1: Authentication
- Extract JWT to get user_id

Step 2: Query History
SELECT j.*, p.enhancement_version
FROM enhancement_jobs j
JOIN master_profiles p ON j.profile_id = p.id
WHERE j.user_id = ?
ORDER BY j.started_at DESC

Step 3: Format Response
- Group by enhancement version
- Include sample versions used
- Calculate components enhanced

Step 4: Response
Return enhancement history array
```

### 4. POST /enhancement/retry - Retry Failed

**Dataflow Implementation:**
```
Step 1: Validate Retry Request
- Get job_id from request
- Verify ownership and failed status

Step 2: Create New Job
- Copy parameters from failed job
- Create new job with status 'processing'

Step 3: Queue Retry
- Queue same tasks with retry flag

Step 4: Response
- Return 202 Accepted with new job_id
```

### 5. GET /enhancement/comparison - Compare Versions

**Dataflow Implementation:**
```
Step 1: Authentication
- Extract JWT to get user_id

Step 2: Load All Versions
Query profile:
SELECT professional_summary, enhanced_summary, previous_enhanced_summary
FROM master_profiles WHERE user_id = ?

Query experiences:
SELECT id, title, description, enhanced_description, previous_enhanced_description
FROM experiences WHERE profile_id = ?

Query projects:
SELECT id, name, description, enhanced_description, previous_enhanced_description
FROM projects WHERE profile_id = ?

Step 3: Format Comparison
- Structure as original vs current vs previous
- Highlight differences if needed

Step 4: Response
Return side-by-side comparison
```

## Async Worker Implementation

### Main Enhancement Worker

**Dataflow:**
```
Step 1: Receive Job Message
- Parse job_id, user_id, tasks

Step 2: Load Required Data
- Load profile and all components
- Load sample documents with extracted styles
- Load custom prompts if provided

Step 3: Execute Tasks Sequentially

Task 1: Extract Combined Style
- Combine resume structure patterns
- Combine cover letter vocabulary/tone
- Create unified style guide

Task 2: Enhance Professional Summary
- Send to LLM with:
  * Original summary
  * Writing style guide
  * Custom prompt
- Store enhanced version

Task 3: Enhance Experiences
For each experience:
- Split description by newline into bullets
- Send each set to LLM with style guide
- Reconstruct as enhanced bullets
- Join with newlines

Task 4: Enhance Projects
For each project:
- Similar to experiences
- Apply style guide to descriptions

Step 4: Apply Rotation Logic
For each enhanced field:
- Check current enhancement_version
- If version >= 1:
    previous = current enhanced
- Set enhanced = new content

Step 5: Update Database
BEGIN TRANSACTION;
- UPDATE master_profiles SET 
    enhanced_summary = ?,
    previous_enhanced_summary = ?,
    enhancement_version = version + 1,
    last_enhanced_at = NOW(),
    enhancement_status = 'completed'
- UPDATE experiences SET ...
- UPDATE projects SET ...
COMMIT;

Step 6: Mark Job Complete
UPDATE enhancement_jobs SET 
  status = 'completed',
  progress = 100,
  completed_at = NOW()
WHERE id = ?
```

### LLM Enhancement Prompts

#### Summary Enhancement Prompt
```
Original Summary: {original_summary}

Writing Style Analysis:
- Vocabulary: {vocabulary_analysis}
- Tone: {tone_analysis}
- Confidence Level: {confidence_level}

Task: Enhance this professional summary using the analyzed writing style.
Requirements:
- Maintain all factual content
- Apply vocabulary and tone from style analysis
- Keep length similar to original
- No fabrication of achievements

{custom_prompt}

Enhanced Summary:
```

#### Experience Enhancement Prompt
```
Original Bullets:
{original_bullets}

Structure Patterns from Resume:
- Format: {bullet_format}
- Average Length: {avg_length}
- Result Emphasis: {result_pattern}
- Metric Usage: {metric_pattern}

Writing Style:
- Action Verbs: {common_verbs}
- Industry Terms: {industry_terms}

Task: Enhance these bullet points following the patterns.
Requirements:
- Keep all facts unchanged
- Apply structure patterns
- Use similar action verbs
- Maintain metric accuracy

Enhanced Bullets:
```

## Enhancement Validation Rules

### Content Preservation Check
```
After each enhancement:
1. Extract key facts (numbers, technologies, companies)
2. Verify all facts present in enhanced version
3. If missing facts, reject enhancement
4. Log validation results
```

### Style Consistency Check
```
1. Analyze enhanced text for style markers
2. Compare with target style guide
3. Calculate consistency score
4. If score < 70%, flag for review
```

## Error Handling

### Retry Logic
```
For transient failures:
- Retry up to 3 times
- Exponential backoff (2s, 4s, 8s)
- If still fails, mark as failed

For LLM errors:
- Log full error details
- Store in error_message field
- Allow manual retry
```

### Rollback on Failure
```
If enhancement fails mid-process:
- Don't update any enhanced fields
- Keep previous versions intact
- Mark job as failed with details
```

## Error Response Standards

| Code | Scenario | Response Body |
|------|----------|---------------|
| 400 | No profile content | `{"error": "Profile has no content to enhance"}` |
| 409 | Already processing | `{"error": "Enhancement already in progress"}` |
| 412 | Missing samples | `{"error": "Upload samples before enhancement"}` |
| 500 | LLM failure | `{"error": "Enhancement failed", "retry": true}` |